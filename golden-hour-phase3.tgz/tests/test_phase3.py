"""Phase 3 tests on synthetic data. They prove definitions and causality, not an edge."""
import os
import tempfile
import unittest

import numpy as np
import pyarrow.parquet as pq

from ghr import holdout, klines, report3, scan
from ghr.config import Settings
from ghr.manifest import Manifest

MIN = 60_000
OCT = 1759276800000  # 2025-10-01T00:00Z


def grid_from(prices, vol=None, t0=OCT):
    n = len(prices)
    p = np.asarray(prices, float)
    v = np.full(n, 1000.0) if vol is None else np.asarray(vol, float)
    return {"t0": t0, "n": n, "open": p.copy(), "high": p * 1.001, "low": p * 0.999,
            "close": p.copy(), "quote_volume": v, "missing": np.zeros(n, bool)}


class TestRolling(unittest.TestCase):
    def test_fwd_extrema_match_brute_force(self):
        rng = np.random.default_rng(1)
        for n, w in ((1000, 7), (999, 60), (50, 50), (3, 10)):
            a = rng.normal(size=n)
            bmax = np.array([a[i:i + w].max() for i in range(n)])
            bmin = np.array([a[i:i + w].min() for i in range(n)])
            np.testing.assert_allclose(scan.fwd_max(a, w), bmax)
            np.testing.assert_allclose(scan.fwd_min(a, w), bmin)
            m = rng.random(n) < 0.1
            np.testing.assert_array_equal(scan.fwd_count(m, w), [m[i:i + w].sum() for i in range(n)])


class TestPumpEvents(unittest.TestCase):
    def shape(self):
        flat = [1.0] * 3000
        up = list(np.linspace(1.0, 1.6, 180))          # +60% over 3h
        down = list(np.linspace(1.6, 1.1, 600))
        tail = [1.1] * 2000
        return flat + up + down + tail

    def test_single_event_measured(self):
        ev = scan.pump_events(grid_from(self.shape()), "XUSDT")
        self.assertEqual(len(ev), 1)
        e = ev[0]
        self.assertEqual(e["band"], "50-100%")
        self.assertAlmostEqual(e["magnitude"], 1.6 * 1.001 / 0.999 - 1, places=3)
        self.assertLess(abs(e["minutes_to_peak"] - 179), 5)
        self.assertLess(e["drop_24h_after_peak"], -0.25)

    def test_small_move_ignored(self):
        p = [1.0] * 2000 + list(np.linspace(1.0, 1.15, 100)) + [1.15] * 2000
        self.assertEqual(scan.pump_events(grid_from(p), "XUSDT"), [])

    def test_no_event_across_gap(self):
        g = grid_from(self.shape())
        g["missing"][3050:3060] = True
        for c in ("open", "high", "low", "close", "quote_volume"):
            g[c][3050:3060] = np.nan
        for e in scan.pump_events(g, "XUSDT"):
            s = (e["start_ms"] - OCT) // MIN
            p = (e["peak_ms"] - OCT) // MIN
            self.assertFalse(s <= 3055 <= p, "event spans a data gap")

    def test_two_legs_merge(self):
        p = ([1.0] * 2000 + list(np.linspace(1.0, 1.3, 120)) + [1.25] * 200
             + list(np.linspace(1.25, 1.7, 120)) + list(np.linspace(1.7, 1.0, 600)) + [1.0] * 2000)
        ev = scan.pump_events(grid_from(p), "XUSDT")
        self.assertEqual(len(ev), 1)
        self.assertEqual(ev[0]["legs"], 2)
        self.assertGreater(ev[0]["magnitude"], 0.65)


class TestTriggers(unittest.TestCase):
    def series(self):
        rng = np.random.default_rng(3)
        n = 6 * 1440
        p = 1.0 * np.exp(np.cumsum(rng.normal(0, 0.001, n)))
        p[4000:4060] *= np.linspace(1.0, 1.25, 60)
        p[4060:] *= 1.25
        v = rng.uniform(800, 1200, n)
        v[4000:4060] *= 20
        return p, v

    def test_fires_on_burst_and_respects_refractory(self):
        p, v = self.series()
        rows = scan.triggers(grid_from(p, v), "XUSDT")
        self.assertTrue(rows)
        by_var = {}
        for r in rows:
            by_var.setdefault(r["variant"], []).append(r["t_ms"])
        for ts in by_var.values():
            self.assertTrue(all(b - a >= 60 * MIN for a, b in zip(ts, ts[1:])))
        self.assertTrue(any(4000 <= (r["t_ms"] - OCT) // MIN < 4060 for r in rows))

    def test_causal_future_does_not_change_signals(self):
        p, v = self.series()
        full = scan.triggers(grid_from(p, v), "XUSDT")
        cut = 4030
        trunc = scan.triggers(grid_from(p[:cut + 1], v[:cut + 1]), "XUSDT")
        key = lambda r: (r["variant"], r["t_ms"], round(r["ret_L"], 12), round(r["volx"], 9))
        lim = OCT + (cut - 1) * MIN  # entry needs minute t+1 to exist in the truncated series
        a = sorted(key(r) for r in full if r["t_ms"] <= lim)
        b = sorted(key(r) for r in trunc if r["t_ms"] <= lim)
        self.assertEqual(a, b)

    def test_no_baseline_first_day(self):
        p, v = self.series()
        rows = scan.triggers(grid_from(p, v), "XUSDT")
        self.assertTrue(all(r["t_ms"] >= OCT + 24 * 60 * MIN for r in rows))


class TestGoldenHourStat(unittest.TestCase):
    def build(self, concentrated):
        rng = np.random.default_rng(5)
        days = 60
        vol_ms = OCT + np.arange(days * 48) * 30 * MIN
        vol = np.full(len(vol_ms), 1e8)
        ev = []
        for d in range(days):
            base = OCT + d * 86_400_000
            ev += list(base + rng.integers(0, 1440, 20) * MIN)
            if concentrated:  # extra events at 13:45 UTC = 09:45 NY (EDT) / 08:45 NY (EST)
                ev += [base + (13 * 60 + 45) * MIN] * 5
        return np.array(ev, np.int64), vol_ms, vol

    def test_detects_concentration(self):
        ev, vms, v = self.build(True)
        r = report3.window_ratio(ev, vms, v, "trading", report3.WINDOW, n_boot=500)
        self.assertGreater(r["ratio"], 2)
        self.assertLess(r["p_one_sided"], 0.01)

    def test_uniform_not_significant(self):
        ev, vms, v = self.build(False)
        r = report3.window_ratio(ev, vms, v, "trading", report3.WINDOW, n_boot=500)
        self.assertGreater(r["p_one_sided"], 0.01)

    def test_dst_handled(self):
        summer = np.array([1782826800000])  # 2026-06-30 13:40 UTC -> 09:40 EDT
        winter = np.array([1767275400000])  # 2026-01-01 13:50 UTC -> 08:50 EST
        self.assertEqual(report3.ny_parts(summer)[1][0], 9 * 60 + 40)
        self.assertEqual(report3.ny_parts(winter)[1][0], 8 * 60 + 50)


class TestRunGuards(unittest.TestCase):
    def test_scan_refuses_holdout(self):
        with tempfile.TemporaryDirectory() as d:
            st = Settings(root=d)
            os.makedirs(st.data_dir)
            mf = Manifest(st.manifest_path)
            with self.assertRaises(holdout.HoldoutLocked):
                scan.run(mf, st, months=("2026-06", "2026-07"), log=lambda *_: None)
            mf.close()

    def test_end_to_end_small(self):
        with tempfile.TemporaryDirectory() as d:
            st = Settings(root=d)
            os.makedirs(st.data_dir)
            mf = Manifest(st.manifest_path)
            p, v = TestTriggers().series()
            n = len(p)
            cols = {"open_time": [OCT + i * MIN for i in range(n)], "open": list(p),
                    "high": list(p * 1.001), "low": list(p * 0.999), "close": list(p),
                    "volume": list(v / p), "close_time": [OCT + i * MIN + 59999 for i in range(n)],
                    "quote_volume": list(v), "trades": [10] * n, "taker_buy_base": list(v / p / 2),
                    "taker_buy_quote": list(v / 2)}
            klines.write_parquet(cols, os.path.join(st.data_dir, "klines", "1m", "XUSDT", "2025-10.parquet"))
            mf.upsert_symbol("XUSDT", in_archive=1, first_month="2025-10", last_month="2025-10")
            out = scan.run(mf, st, months=("2025-10",), log=lambda *_: None)
            self.assertTrue(os.path.exists(os.path.join(out, "pump_events.parquet")))
            text = report3.report(out)
            self.assertIn("TRIGGER BASE RATES", text)
            self.assertIn("GOLDEN HOUR TEST", text)
            mf.close()


if __name__ == "__main__":
    unittest.main()
