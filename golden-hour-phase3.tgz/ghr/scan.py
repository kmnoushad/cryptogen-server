"""Phase 3 scanner. Definitions fixed before looking at results (16 Oct 2026).

Two separate outputs, never mixed:

1. PUMP EVENTS (hindsight, description only). A rise of >= 20% from a local low
   to a high within 24h on 1m candles. Overlapping legs on one coin merge into a
   single event while price stays above the event's starting low and the next
   leg starts within 24h of the previous peak. The event "begins" at the last
   minute before the peak that is still within 1% of the low. Never used to
   make decisions.

2. TRIGGERS (causal). At the close of minute t, a fixed grid of 27 variants:
   return over L in {5,15,60} min >= X in {3,5,8}% AND quote volume over those L
   minutes >= V in {3,5,10} x the baseline (median hourly quote volume of the 24
   complete hours before t's hour, scaled to L). Only data up to t's close is
   used. A 60-minute refractory period per symbol and variant stops one move
   counting many times. Outcomes are measured from the NEXT minute's open.

No measurement spans a data gap: windows containing a missing minute are
discarded. Nothing is interpolated.
"""
import os

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

from . import holdout

MIN = 60_000
DAY = 1440
PUMP_MIN = 0.20
BANDS = ((0.20, "20-50%"), (0.50, "50-100%"), (1.00, "100-200%"), (2.00, "200%+"))
LOOKBACKS = (5, 15, 60)
RETS = (0.03, 0.05, 0.08)
VOLX = (3, 5, 10)
REFRACTORY = 60
HORIZONS = (240, 1440)
DEV_MONTHS = tuple(f"{y}-{m:02d}" for y, m in
                   [(2025, 10), (2025, 11), (2025, 12), (2026, 1), (2026, 2), (2026, 3), (2026, 4)])


def band(mag):
    out = None
    for lo, name in BANDS:
        if mag >= lo:
            out = name
    return out


# ---------- loading ----------

def load_grid(settings, symbol, months, purpose):
    """Contiguous minute grid from first to last row; missing minutes are NaN."""
    tables = holdout.read_klines(settings, symbol, months, purpose,
                                 columns=["open_time", "open", "high", "low", "close", "quote_volume"])
    if not tables:
        return None
    t = pa.concat_tables(tables)
    ts = t.column("open_time").to_numpy()
    order = np.argsort(ts, kind="stable")
    ts = ts[order]
    idx = (ts - ts[0]) // MIN
    n = int(idx[-1]) + 1
    g = {"t0": int(ts[0]), "n": n}
    for c in ("open", "high", "low", "close", "quote_volume"):
        a = np.full(n, np.nan)
        a[idx] = t.column(c).to_numpy()[order]
        g[c] = a
    g["missing"] = np.isnan(g["close"])
    return g


# ---------- O(n) rolling extrema (van Herk / Gil-Werman), forward-looking ----------

def fwd_max(a, w):
    """out[i] = max(a[i : i+w]) (shorter at the end). NaN-free input expected."""
    n = len(a)
    pad = (-n) % w
    b = np.concatenate([a, np.full(pad, -np.inf)]).reshape(-1, w)
    suffix = np.maximum.accumulate(b[:, ::-1], axis=1)[:, ::-1].ravel()
    prefix = np.maximum.accumulate(b, axis=1).ravel()
    prefix = np.concatenate([prefix, np.full(w, -np.inf)])
    return np.maximum(suffix[:n], prefix[np.arange(n) + w - 1])


def fwd_min(a, w):
    return -fwd_max(-a, w)


def fwd_count(mask, w):
    c = np.concatenate([[0], np.cumsum(mask.astype(np.int64))])
    i = np.arange(len(mask))
    return c[np.minimum(i + w, len(mask))] - c[i]


# ---------- 1. pump events (hindsight) ----------

def pump_events(g, symbol, funding=None, listing_ms=None):
    hi = np.where(g["missing"], -np.inf, g["high"])
    lo = np.where(g["missing"], np.inf, g["low"])
    n = g["n"]
    fmax = fwd_max(hi, DAY + 1)              # highs over [t, t+24h]
    gaps = fwd_count(g["missing"], DAY + 1)  # any missing minute in the window
    cand = (fmax >= lo * (1 + PUMP_MIN)) & (gaps == 0) & np.isfinite(lo)
    events, i = [], 0
    starts = np.flatnonzero(cand)
    while True:
        j = np.searchsorted(starts, i)
        if j >= len(starts):
            break
        s = int(starts[j])
        # refine: start = lowest low before the peak; peak = highest high within 24h of start
        for _ in range(5):
            p = s + int(np.argmax(hi[s:s + DAY + 1]))
            s2 = s + int(np.argmin(lo[s:p + 1]))
            if s2 == s:
                break
            s = s2
        p = s + int(np.argmax(hi[s:s + DAY + 1]))
        legs = 1
        # merge continuation legs
        while True:
            k = np.searchsorted(starts, p + 1)
            if k >= len(starts):
                break
            s_next = int(starts[k])
            if s_next > p + DAY or np.nanmin(lo[s:s_next + 1]) < lo[s]:
                break
            if g["missing"][p:s_next + 1].any():
                break
            p_next = s_next + int(np.argmax(hi[s_next:s_next + DAY + 1]))
            if hi[p_next] <= hi[p]:
                break
            p, legs = p_next, legs + 1
        mag = hi[p] / lo[s] - 1
        if mag >= PUMP_MIN:
            events.append(_describe(g, symbol, s, p, legs, mag, funding, listing_ms))
        i = p + 1
    return events


def _describe(g, symbol, s, p, legs, mag, funding, listing_ms):
    hi, lo, close, qv = g["high"], g["low"], g["close"], g["quote_volume"]
    n = g["n"]
    # pullbacks >= 5% from the running high during the run-up
    run_hi, pullbacks, in_pb = lo[s], 0, False
    for t in range(s, p + 1):
        if hi[t] > run_hi:
            run_hi, in_pb = hi[t], False
        if not in_pb and lo[t] <= run_hi * 0.95 and t < p:
            pullbacks, in_pb = pullbacks + 1, True
    post_end = min(n, p + 1 + DAY)
    post = lo[p + 1:post_end]
    post_ok = len(post) == DAY and not g["missing"][p + 1:post_end].any()
    post_min = float(np.nanmin(post)) if len(post) else np.nan
    drop24 = post_min / hi[p] - 1 if post_ok else np.nan
    t20 = np.nan
    if post_ok:
        hit = np.flatnonzero(post <= hi[p] * 0.80)
        t20 = float(hit[0] + 1) if len(hit) else np.nan
    # The move "begins" at the last minute before the peak still within 1% of the low;
    # the low itself can sit hours earlier on a flat base.
    seg = lo[s:p + 1]
    b = s + int(np.flatnonzero(seg <= lo[s] * 1.01)[-1])
    pre = qv[max(0, b - DAY):b]
    pre_qv = float(np.nansum(pre)) if len(pre) == DAY else np.nan
    start_ms = g["t0"] + b * MIN
    fr = np.nan
    if funding is not None and len(funding[0]):
        k = np.searchsorted(funding[0], start_ms, side="right") - 1
        if k >= 0:
            fr = float(funding[1][k])
    return dict(
        symbol=symbol, start_ms=start_ms, low_ms=g["t0"] + s * MIN, peak_ms=g["t0"] + p * MIN,
        low_price=float(lo[s]), peak_price=float(hi[p]), magnitude=float(mag), band=band(mag),
        minutes_to_peak=int(p - b), legs=legs, pullbacks_5pct=pullbacks,
        drop_24h_after_peak=float(drop24), minutes_to_minus20_from_peak=t20,
        quote_vol_24h_before=pre_qv, quote_vol_run=float(np.nansum(qv[s:p + 1])),
        funding_at_start=fr,
        days_since_listing=(float((start_ms - listing_ms) / 86_400_000) if listing_ms else np.nan),
    )


# ---------- 2. causal triggers ----------

def hourly_baseline(g):
    """Per minute: median of the 24 complete hours' quote volume before this minute's hour,
    in quote units per minute. NaN when any of those hours has a missing minute."""
    n = g["n"]
    first_hour_off = (-(g["t0"] // MIN)) % 60  # minutes until the first full UTC hour
    qv = g["quote_volume"]
    base = np.full(n, np.nan)
    hours = []
    h0 = first_hour_off
    while h0 + 60 <= n:
        seg = qv[h0:h0 + 60]
        hours.append(np.nan if np.isnan(seg).any() else float(seg.sum()))
        h0 += 60
    hours = np.array(hours)
    for h in range(24, len(hours) + 1):
        win = hours[h - 24:h]
        start = first_hour_off + h * 60  # the hour these 24 precede
        if start >= n:
            break
        if not np.isnan(win).any():
            base[start:min(n, start + 60)] = np.median(win) / 60.0
    return base


def triggers(g, symbol):
    close, open_, hi, lo, qv = g["close"], g["open"], g["high"], g["low"], g["quote_volume"]
    n = g["n"]
    base = hourly_baseline(g)
    cq = np.concatenate([[0.0], np.cumsum(np.nan_to_num(qv))])
    miss = np.concatenate([[0], np.cumsum(g["missing"].astype(np.int64))])
    hi_f = np.where(g["missing"], -np.inf, hi)
    lo_f = np.where(g["missing"], np.inf, lo)
    # outcome windows start at t+1 (entry at next minute's open)
    fwd = {}
    for h in HORIZONS:
        mx = fwd_max(hi_f, h)
        mn = fwd_min(lo_f, h)
        gp = fwd_count(g["missing"], h)
        fwd[h] = (np.concatenate([mx[1:], [np.nan]]), np.concatenate([mn[1:], [np.nan]]),
                  np.concatenate([gp[1:], [h]]))
    rows = []
    idx = np.arange(n)
    for L in LOOKBACKS:
        valid = idx >= L
        prev = np.where(valid, np.roll(close, L), np.nan)
        ret = close / prev - 1
        vol_L = np.where(valid, cq[idx + 1] - cq[np.maximum(idx + 1 - L, 0)], np.nan)
        gap_L = np.where(valid, miss[idx + 1] - miss[np.maximum(idx + 1 - L, 0)], 1)
        volx = vol_L / (base * L)
        ok = valid & (gap_L == 0) & np.isfinite(ret) & np.isfinite(volx)
        for X in RETS:
            for V in VOLX:
                hits = np.flatnonzero(ok & (ret >= X) & (volx >= V))
                last = -10**9
                for t in hits:
                    if t - last < REFRACTORY or t + 1 >= n or g["missing"][t + 1]:
                        continue
                    last = t
                    entry = open_[t + 1]
                    r = dict(symbol=symbol, variant=f"L{L}_R{int(X*100)}_V{V}", lookback=L,
                             ret_thr=X, vol_thr=V, t_ms=g["t0"] + t * MIN, entry=float(entry),
                             ret_L=float(ret[t]), volx=float(volx[t]))
                    for h in HORIZONS:
                        mx, mn, gp = fwd[h][0][t], fwd[h][1][t], fwd[h][2][t]
                        complete = gp == 0 and t + h < n
                        r[f"mfe_{h}"] = float(mx / entry - 1) if complete else np.nan
                        r[f"mae_{h}"] = float(mn / entry - 1) if complete else np.nan
                        end = t + h
                        r[f"ret_{h}"] = (float(close[end] / entry - 1)
                                         if complete and not np.isnan(close[end]) else np.nan)
                    rows.append(r)
    return rows


# ---------- driver ----------

def write_rows(rows, path):
    if not rows:
        return 0
    cols = {k: [r[k] for r in rows] for k in rows[0]}
    os.makedirs(os.path.dirname(path), exist_ok=True)
    pq.write_table(pa.table(cols), path + ".tmp", compression="zstd")
    os.replace(path + ".tmp", path)
    return len(rows)


def market_volume(g, acc, bucket_min=30):
    """Accumulate market-wide quote volume per 30-minute UTC bucket."""
    qv = np.nan_to_num(g["quote_volume"])
    ts = g["t0"] + np.arange(g["n"]) * MIN
    b = ts // (bucket_min * MIN)
    uniq, inv = np.unique(b, return_inverse=True)
    sums = np.bincount(inv, weights=qv)
    for k, v in zip(uniq.tolist(), sums.tolist()):
        acc[k] = acc.get(k, 0.0) + v


def run(manifest, settings, months=DEV_MONTHS, log=print, symbols=None):
    for m in months:
        if m in settings.holdout_months:
            raise holdout.HoldoutLocked(f"scan refuses holdout month {m}")
    out_dir = os.path.join(settings.root, "phase3", "_".join([months[0], months[-1]]))
    sym_rows = manifest.db.execute(
        "SELECT symbol, onboard_ms, first_month, last_month FROM symbols WHERE in_archive=1 ORDER BY symbol").fetchall()
    if symbols:
        sym_rows = [r for r in sym_rows if r[0] in symbols]
    sym_rows = [r for r in sym_rows if r[2] and r[2] <= months[-1] and (r[3] or r[2]) >= months[0]]
    ev_all, tr_count, vol_acc = [], 0, {}
    part = os.path.join(out_dir, "triggers")
    for i, (sym, onboard, first_m, _) in enumerate(sym_rows, 1):
        g = load_grid(settings, sym, months, purpose="phase3-scan-dev")
        if g is None:
            continue
        fpath = os.path.join(settings.data_dir, "funding", f"{sym}.parquet")
        funding = None
        if os.path.exists(fpath):
            ft = pq.read_table(fpath)
            funding = (ft.column("funding_time").to_numpy(), ft.column("funding_rate").to_numpy())
        listing = onboard if onboard else None
        ev_all += pump_events(g, sym, funding, listing)
        tr_count += write_rows(triggers(g, sym), os.path.join(part, f"{sym}.parquet"))
        market_volume(g, vol_acc)
        if i % 50 == 0:
            log(f"scan: {i}/{len(sym_rows)} symbols, {len(ev_all)} pump events, {tr_count} triggers")
    write_rows(ev_all, os.path.join(out_dir, "pump_events.parquet"))
    keys = sorted(vol_acc)
    pq.write_table(pa.table({"bucket_ms": pa.array([k * 30 * MIN for k in keys], pa.int64()),
                             "quote_volume": pa.array([vol_acc[k] for k in keys], pa.float64())}),
                   os.path.join(out_dir, "market_volume_30m.parquet"), compression="zstd")
    log(f"scan finished: {len(sym_rows)} symbols, {len(ev_all)} pump events, {tr_count} triggers -> {out_dir}")
    return out_dir
