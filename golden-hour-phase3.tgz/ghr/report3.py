"""Phase 3 report: trigger base rates, pump-event summary, Golden Hour test.

Golden Hour test (pre-registered 16 Oct 2026):
  unit      = pooled triggers (any of the 27 variants), deduped to one per symbol
              per 60 minutes; secondary unit = pump-event starts (>= 20%).
  exposure  = market-wide quote volume in the same 30-minute bucket, so "more
              pumps because more trading" does not count as an effect.
  window    = 08:30-10:30 New York time (DST handled), US trading days only.
  statistic = (events / volume inside window) / (events / volume outside window).
  inference = bootstrap over New York calendar days (5,000 resamples), one-sided.
  pass bar  = ratio > 1 with p < 0.01; also must hold out of sample later.
Weekends and US market holidays are reported separately as the natural control:
crypto trades, US equities do not.
"""
import glob
import os
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

MIN = 60_000
NY = ZoneInfo("America/New_York")
# NYSE full-day closures (verify before extending the date range).
US_MARKET_HOLIDAYS = {
    "2025-11-27", "2025-12-25", "2026-01-01", "2026-01-19", "2026-02-16", "2026-04-03",
    "2026-05-25", "2026-06-19", "2026-07-03", "2026-09-07",
}
WINDOW = (8 * 60 + 30, 10 * 60 + 30)  # minutes after NY midnight
SUB_WINDOWS = {"08:30-09:30": (510, 570), "09:30-10:30": (570, 630)}


def ny_offsets(ms):
    """Vectorised NY UTC-offset in ms, via a per-UTC-hour lookup table."""
    hours = ms // 3_600_000
    uniq = np.unique(hours)
    table = {h: int(datetime.fromtimestamp(h * 3600, tz=timezone.utc).astimezone(NY)
                    .utcoffset().total_seconds() * 1000) for h in uniq.tolist()}
    return np.array([table[h] for h in hours.tolist()], dtype=np.int64)


def ny_parts(ms):
    local = ms + ny_offsets(ms)
    day = local // 86_400_000
    minute = (local % 86_400_000) // MIN
    weekday = (day + 3) % 7  # 1970-01-01 was a Thursday -> Monday=0
    return day, minute, weekday


def day_kind(day, weekday):
    if not len(day):
        return np.array([], dtype="<U8")
    uniq, inv = np.unique(day, return_inverse=True)
    is_hol = np.array([datetime.fromtimestamp(int(d) * 86400, tz=timezone.utc).strftime("%Y-%m-%d")
                       in US_MARKET_HOLIDAYS for d in uniq.tolist()])
    hol = is_hol[inv]
    kind = np.where(weekday >= 5, "weekend", np.where(hol, "holiday", "trading"))
    return kind


def dedupe_pooled(sym, t):
    order = np.lexsort((t, sym))
    keep = np.zeros(len(t), bool)
    last_sym, last_t = None, -10**18
    for i in order:
        if sym[i] != last_sym or t[i] - last_t >= 60 * MIN:
            keep[i] = True
            last_sym, last_t = sym[i], t[i]
    return keep


def window_ratio(ev_ms, vol_ms, vol, kind_filter, window, n_boot=5000, seed=7):
    """Volume-normalised rate inside vs outside the NY window, day-block bootstrap."""
    eday, emin, ewd = ny_parts(ev_ms)
    vday, vmin, vwd = ny_parts(vol_ms)
    ek, vk = day_kind(eday, ewd), day_kind(vday, vwd)
    lo, hi = window
    e_in = (emin >= lo) & (emin < hi)
    v_in = (vmin >= lo) & (vmin < hi)
    days = np.unique(vday[vk == kind_filter])
    if len(days) < 5:
        return None
    di = {d: i for i, d in enumerate(days.tolist())}
    nd = len(days)
    agg = np.zeros((nd, 4))  # ev_in, ev_out, vol_in, vol_out
    for d, inside in zip(eday[ek == kind_filter].tolist(), e_in[ek == kind_filter].tolist()):
        if d in di:
            agg[di[d], 0 if inside else 1] += 1
    for d, inside, v in zip(vday[vk == kind_filter].tolist(), v_in[vk == kind_filter].tolist(),
                            vol[vk == kind_filter].tolist()):
        agg[di[d], 2 if inside else 3] += v

    def ratio(a):
        s = a.sum(axis=0)
        if s[1] == 0 or s[2] == 0 or s[3] == 0:
            return np.nan
        return (s[0] / s[2]) / (s[1] / s[3])

    point = ratio(agg)
    rng = np.random.default_rng(seed)
    boots = np.array([ratio(agg[rng.integers(0, nd, nd)]) for _ in range(n_boot)])
    boots = boots[np.isfinite(boots)]
    p = float((boots <= 1.0).mean()) if len(boots) else np.nan
    lo_ci, hi_ci = (np.percentile(boots, [2.5, 97.5]) if len(boots) else (np.nan, np.nan))
    return dict(days=nd, ev_in=int(agg[:, 0].sum()), ev_out=int(agg[:, 1].sum()),
                ratio=float(point), ci=(float(lo_ci), float(hi_ci)), p_one_sided=p)


def load_triggers(out_dir, cols):
    files = sorted(glob.glob(os.path.join(out_dir, "triggers", "*.parquet")))
    if not files:
        return None
    return pa.concat_tables([pq.read_table(f, columns=cols) for f in files])


def fmt_pct(x):
    return "   n/a" if not np.isfinite(x) else f"{x*100:6.1f}%"


def report(out_dir, log=print):
    lines = []
    P = lines.append
    P(f"PHASE 3 REPORT  ({out_dir})")
    P("All figures are from development months only. Nothing here is a backtest:")
    P("no fees, slippage, stops or position sizing are applied.\n")

    # ---- pump events
    ev = pq.read_table(os.path.join(out_dir, "pump_events.parquet"))
    band = np.array(ev.column("band").to_pylist())
    mag = ev.column("magnitude").to_numpy()
    drop = ev.column("drop_24h_after_peak").to_numpy(zero_copy_only=False)
    mtp = ev.column("minutes_to_peak").to_numpy()
    P(f"PUMP EVENTS (hindsight): {len(mag)} events on "
      f"{len(set(ev.column('symbol').to_pylist()))} symbols")
    for b in ("20-50%", "50-100%", "100-200%", "200%+"):
        m = band == b
        if m.any():
            d = drop[m]
            d = d[np.isfinite(d)]
            P(f"  {b:9} n={m.sum():5d}  median hours to peak={np.median(mtp[m])/60:5.1f}  "
              f"median 24h drop after peak={fmt_pct(np.median(d)) if len(d) else '   n/a'}  "
              f"share falling >=20% from peak within 24h={fmt_pct((d <= -0.20).mean()) if len(d) else '   n/a'}")
    P("")

    # ---- trigger base rates
    cols = ["symbol", "variant", "t_ms", "mfe_240", "mae_240", "ret_240", "mfe_1440", "ret_1440"]
    tr = load_triggers(out_dir, cols)
    if tr is None:
        P("No triggers found.")
        return "\n".join(lines)
    var = np.array(tr.column("variant").to_pylist())
    get = lambda c: tr.column(c).to_numpy(zero_copy_only=False).astype(float)
    mfe240, mae240, r240, mfe1440, r1440 = (get(c) for c in ("mfe_240", "mae_240", "ret_240", "mfe_1440", "ret_1440"))
    P("TRIGGER BASE RATES (entry = next minute's open; costs NOT deducted)")
    P(f"{'variant':16} {'n':>6} {'+20%/24h':>9} {'+50%/24h':>9} {'+100%/24h':>9} "
      f"{'med MFE4h':>9} {'med MAE4h':>9} {'med ret4h':>9} {'ret4h>0':>8} {'med ret24h':>10}")
    for v in sorted(set(var.tolist()), key=lambda s: tuple(int(x[1:]) for x in s.split("_"))):
        m = var == v
        f24 = np.isfinite(mfe1440[m])
        a = mfe1440[m][f24]
        rr = r240[m][np.isfinite(r240[m])]
        r24 = r1440[m][np.isfinite(r1440[m])]
        P(f"{v:16} {m.sum():6d} {fmt_pct((a >= .2).mean()) if len(a) else '   n/a':>9} "
          f"{fmt_pct((a >= .5).mean()) if len(a) else '   n/a':>9} {fmt_pct((a >= 1).mean()) if len(a) else '   n/a':>9} "
          f"{fmt_pct(np.nanmedian(mfe240[m])):>9} {fmt_pct(np.nanmedian(mae240[m])):>9} "
          f"{fmt_pct(np.median(rr)) if len(rr) else '   n/a':>9} {fmt_pct((rr > 0).mean()) if len(rr) else '   n/a':>8} "
          f"{fmt_pct(np.median(r24)) if len(r24) else '   n/a':>10}")
    P("")

    # ---- Golden Hour
    vol = pq.read_table(os.path.join(out_dir, "market_volume_30m.parquet"))
    vms = vol.column("bucket_ms").to_numpy()
    vqv = vol.column("quote_volume").to_numpy()
    sym = np.array(tr.column("symbol").to_pylist())
    tms = tr.column("t_ms").to_numpy()
    keep = dedupe_pooled(sym, tms)
    pooled = tms[keep]
    starts = ev.column("start_ms").to_numpy()
    P("GOLDEN HOUR TEST  (rate per unit of market volume, inside vs outside the window)")
    P(f"pooled triggers after dedupe: {len(pooled)};  pump-event starts: {len(starts)}")
    for unit, ms in (("pooled triggers", pooled), ("pump starts", starts)):
        for kind in ("trading", "weekend", "holiday"):
            for wname, w in [("08:30-10:30 (primary)", WINDOW)] + list(SUB_WINDOWS.items()):
                if kind != "trading" and wname != "08:30-10:30 (primary)":
                    continue
                res = window_ratio(ms, vms, vqv, kind, w)
                if res is None:
                    P(f"  {unit:15} {kind:8} {wname:22} too few days")
                    continue
                P(f"  {unit:15} {kind:8} {wname:22} days={res['days']:3d} in={res['ev_in']:5d} "
                  f"out={res['ev_out']:6d} ratio={res['ratio']:.2f} "
                  f"95%CI=({res['ci'][0]:.2f},{res['ci'][1]:.2f}) p={res['p_one_sided']:.4f}")
    P("")
    P("Reading: ratio > 1 means more triggers per dollar traded inside the window than")
    P("outside. Primary pass bar: trading days, pooled triggers, ratio > 1, p < 0.01.")
    P("Macro-release days are NOT yet excluded; that check needs a verified date list.")

    # NY 30-minute profile for trading days
    day, minute, wd = ny_parts(pooled)
    k = day_kind(day, wd)
    vday, vmin, vwd = ny_parts(vms)
    vk = day_kind(vday, vwd)
    P("\nNY 30-min profile, US trading days (triggers per $1B market volume):")
    slots = []
    for s in range(48):
        e = ((minute // 30) == s) & (k == "trading")
        v = vqv[((vmin // 30) == s) & (vk == "trading")].sum()
        slots.append((s, e.sum(), e.sum() / (v / 1e9) if v else np.nan))
    for s, n, rate in slots:
        mark = "  <-- window" if WINDOW[0] <= s * 30 < WINDOW[1] else ""
        P(f"  {s//2:02d}:{(s%2)*30:02d} NY  n={n:5d}  rate={rate:7.3f}{mark}")
    text = "\n".join(lines)
    with open(os.path.join(out_dir, "REPORT.txt"), "w") as f:
        f.write(text + "\n")
    return text
