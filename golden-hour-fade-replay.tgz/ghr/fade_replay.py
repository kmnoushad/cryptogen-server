"""Replay of the LIVE Fade spike mode (v6.9.47, commit c4abe7b) on historical trades.

Ported faithfully from src/spike-fade-detector.js, src/entry-quality.js,
src/fade-orders.js (entryPlan / exitPlan / structuralFadeStop) and the
FadeExecutor management loop. Nothing is tuned: every threshold is the live one.

Approximations (stated in the report):
  * No historical order book: bid = last taker-SELL print, ask = last taker-BUY
    print within 5 s (else ask = bid). Spread gates use these proxies.
  * BTC context from 1m klines: 15m return = close[m-1]/close[m-16]-1, and the
    30s return is approximated by the last full minute's return.
  * Funding gate uses the last SETTLED rate (the live gate reads the predicted rate).
  * Not modelled: open-interest gate, macro-event / Fed-day gate, daily loss lock,
    two-loss cooldown, adverse-position hold, exchange min-notional skips. These
    only remove trades; they cannot turn a losing per-trade rule into a winning one,
    but they mean replay trade COUNTS exceed live counts.
  * Entry latency 1 s; the executor polls every 5 s; stops are exchange-native
    (fill = first taker-BUY print at/after the trigger); the 75% target is a resting
    limit that fills only when a trade prints strictly below it (maker fee 0.02%).
  * Trade data is replayed for 60 minutes after entry; positions still open then
    continue on 1m klines (stop checked before target in the same minute), max 7 days.

Sampling: candidate coin-days are those with any 2-minute window whose high/low
range is >= 2% (a superset of every possible 30-second 2% spike). A uniform random
sample of candidate coin-days is replayed in full; days without a candidate minute
cannot produce a signal, so per-day results scale to the whole universe.
"""
import collections
import io
import os
import zipfile

import numpy as np
import pyarrow as pa
import pyarrow.csv as pacsv
import pyarrow.parquet as pq

from . import holdout, klines, net, scan
from .phase4 import _download, aggtrades_url

MIN = scan.MIN
FEE = 0.0005          # taker, as modelled by the live bot
MAKER = 0.0002        # resting 75% target
EXIT_SLIP = 0.0005    # live modelled exit slippage
LAT_MS = 1000
POLL_MS = 5000
TRADE_HORIZON_MS = 60 * MIN
COLS = ["agg_trade_id", "price", "quantity", "first_trade_id", "last_trade_id",
        "transact_time", "is_buyer_maker"]


# ------------------------------------------------------------- entry quality

def entry_quality(entry, stop, reference, fee=FEE, exit_slip=EXIT_SLIP):
    """SHORT branch of src/entry-quality.js."""
    distance = stop - entry
    if distance <= 0:
        return False, "Structural invalidation reached"
    costs = entry * fee + stop * (fee + exit_slip)
    cost_share = costs / (distance + costs)
    chase = reference - entry
    chase_limit = min(reference * 0.0015, distance * 0.25)
    if chase > chase_limit + 1e-10:
        return False, "Price advanced beyond no-chase budget"
    if cost_share > 0.25 + 1e-10:
        return False, "Modeled costs > 25% of stop risk"
    return True, "ok"


# ------------------------------------------------------------- detector port

class Detector:
    """src/spike-fade-detector.js, one symbol."""

    def __init__(self):
        self.ticks = collections.deque()
        self.id = -1
        self.time = -1
        self.window_start = None
        self.watch = None
        self.cooldown = 0
        self.evaluated = -10**18
        self.last_buy = (None, -10**18)
        self.last_sell = (None, -10**18)

    def book(self, now):
        bid = self.last_sell[0]
        if bid is None:
            return None, None
        ask = self.last_buy[0] if now - self.last_buy[1] <= 5000 and self.last_buy[0] else bid
        return bid, max(ask, bid)

    def ingest(self, tid, time, price, qty, sell, btc_ok):
        if tid <= self.id or time < self.time or not (price > 0 and qty > 0):
            return None
        if sell:
            self.last_sell = (price, time)
        else:
            self.last_buy = (price, time)
        if self.window_start is None:
            self.window_start = time
        if self.time >= 0 and time - self.time > 5000:
            self.watch = None
            self.window_start = time
        self.id, self.time = tid, time
        second = time // 1000
        q = price * qty
        if self.ticks and self.ticks[-1][0] == second:
            b = self.ticks[-1]
            b[1] = time
            b[4] += q
            b[5] += q if sell else 0.0
            b[6] += 1
        else:  # [second, time, firstTime, price, quote, sellQuote, count]
            self.ticks.append([second, time, time, price, q, q if sell else 0.0, 1])
        while self.ticks and time - self.ticks[0][2] > 150000:
            self.ticks.popleft()
        w = self.watch
        if w and price > w["high"]:
            w["high"], w["highAt"] = price, time
        if time - self.evaluated < 250:
            return None
        self.evaluated = time
        if time < self.cooldown:
            return None
        if w and time - w["started"] > 45000:
            self.watch = w = None
        if not w:
            if not self.ticks or time - self.ticks[0][2] < 140000:
                return None
            base_q = sum(t[4] for t in self.ticks if time - t[1] > 30000)
            if not any(time - t[1] > 30000 for t in self.ticks):
                return None
            burst = [t for t in self.ticks if time - t[1] <= 30000 and t[1] >= self.window_start]
            if not burst:
                return None
            quote = sum(t[4] for t in burst)
            gain = price / burst[0][3] - 1
            if gain < 0.02 or quote < (base_q / 120) * 30 * 3:
                return None
            self.watch = dict(started=time, highAt=time, high=price, gain=gain, quote=quote)
            return None
        if price > w["high"]:
            w["high"], w["highAt"] = price, time
        retreat = 1 - price / w["high"]
        if retreat > 0.009:
            self.watch = None
            self.cooldown = time + 60000
            return None
        if retreat < 0.005 or time - w["highAt"] < 2000:
            return None
        flow = [t for t in self.ticks if time - t[1] <= 5000]
        fq = sum(t[4] for t in flow)
        if fq <= 0 or sum(t[5] for t in flow) / fq < 0.6 or sum(t[6] for t in flow) < 3:
            return None
        if not btc_ok:
            return None
        bid, ask = self.book(time)
        if bid is None or not (bid > 0 and ask >= bid) or ask / bid - 1 > 0.001:
            return None
        ok, _ = entry_quality(bid, w["high"] * 1.001, price)
        if not ok or 1 - bid / w["high"] > 0.009:
            return None
        sig = dict(t=time, entry=bid, price=bid, resistance=w["high"], gain=w["gain"])
        self.watch = None
        self.cooldown = time + 60000
        return sig


# ------------------------------------------------------------- aggTrades I/O

def iter_windows(zip_path, windows):
    """Stream a daily aggTrades zip in batches; yield arrays of rows inside any
    [start, end] window (ms), in file order (= trade id order)."""
    starts = np.array([w[0] for w in windows], np.int64)
    ends = np.array([w[1] for w in windows], np.int64)
    with zipfile.ZipFile(zip_path) as z:
        name = [n for n in z.namelist() if n.endswith(".csv")][0]
        with z.open(name) as fh:
            first = fh.readline().decode("ascii", "ignore")
        header = not first.split(",")[0].strip().isdigit()
        ro = pacsv.ReadOptions(block_size=1 << 22, column_names=None if header else COLS)
        co = pacsv.ConvertOptions(include_columns=["agg_trade_id", "price", "quantity",
                                                   "transact_time", "is_buyer_maker"],
                                  column_types={"agg_trade_id": pa.int64(), "price": pa.float64(),
                                                "quantity": pa.float64(), "transact_time": pa.int64(),
                                                "is_buyer_maker": pa.bool_()})
        with z.open(name) as fh:
            for batch in pacsv.open_csv(fh, read_options=ro, convert_options=co):
                t = batch.column("transact_time").to_numpy()
                t = np.where(t > 10**14, t // 1000, t)
                i = np.searchsorted(starts, t, side="right") - 1
                m = (i >= 0) & (t <= ends[np.clip(i, 0, None)])
                if m.any():
                    yield dict(id=batch.column("agg_trade_id").to_numpy()[m], t=t[m],
                               p=batch.column("price").to_numpy()[m],
                               q=batch.column("quantity").to_numpy()[m],
                               sell=batch.column("is_buyer_maker").to_numpy(zero_copy_only=False)[m])


def read_windows(zip_path, windows):
    parts = list(iter_windows(zip_path, windows))
    if not parts:
        return {k: np.array([]) for k in ("id", "t", "p", "q", "sell")}
    out = {k: np.concatenate([b[k] for b in parts]) for k in parts[0]}
    o = np.argsort(out["id"], kind="stable")
    return {k: v[o] for k, v in out.items()}


def merge(windows):
    out = []
    for s, e in sorted(windows):
        if out and s <= out[-1][1]:
            out[-1][1] = max(out[-1][1], e)
        else:
            out.append([s, e])
    return out


# ------------------------------------------------------------- exits

def manage(sig, tr, entry_idx, E, stop, kl=None):
    """Live executor management from the entry fill. tr = trade arrays (sorted).
    Returns dict with pnl per unit, R, exit reason, how resolved."""
    r = stop * (1 + FEE + EXIT_SLIP) - E * (1 - FEE)
    target = (E - (1.5 * r + E * FEE) / 0.75) / (1 + FEE)
    be = E * (1 - FEE) / (1 + FEE + EXIT_SLIP)
    cur = stop
    tp = False
    low_ask = None
    t0 = tr["t"][entry_idx]
    next_poll = t0 + POLL_MS
    last_buy = None
    pnl = -E * FEE  # entry fee per unit
    n = len(tr["t"])
    horizon = t0 + TRADE_HORIZON_MS

    def close_rest(px, why, how):
        nonlocal pnl
        frac = 0.25 if tp else 1.0
        pnl += frac * (E - px) - frac * px * FEE
        return dict(pnl=pnl, R=pnl / r, reason=why, resolved=how, tp=tp, target=target, r=r,
                    exit_px=px, be_moved=cur == be)

    k = entry_idx + 1
    while k < n and tr["t"][k] <= horizon:
        ts, px, sell = tr["t"][k], tr["p"][k], tr["sell"][k]
        if not sell:
            last_buy = px
        if px >= cur:  # native STOP_MARKET on last price; market buy fills at the next taker-buy print
            j = k
            while j < n and tr["sell"][j]:
                j += 1
            fill = float(tr["p"][j]) if j < n else float(px)
            return close_rest(fill, "stop" if not tp else "runner_stop", "trades")
        if not tp and px < target:
            tp = True
            pnl += 0.75 * (E - target) - 0.75 * target * MAKER
            low_ask = px
        while ts >= next_poll:
            ask = last_buy if last_buy is not None else px
            if not tp:
                net_ = (E - ask) - E * FEE - ask * (FEE + EXIT_SLIP)
                if net_ >= 0.5 * r and ask < be and be < cur:
                    cur = be
            else:
                low_ask = min(low_ask, ask)
                nxt = min(stop, be, low_ask * 1.0075)
                if ask >= nxt:
                    return close_rest(ask, "runner_trail", "trades")
                cur = min(cur, nxt)
            next_poll += POLL_MS
        k += 1
    # continue on 1m klines
    if kl is None:
        return None
    g, start = kl
    m = (max(int(horizon), int(t0)) - g["t0"]) // MIN + 1
    for _ in range(7 * 1440):
        if m >= g["n"] or g["missing"][m]:
            return None
        hi, lo, cl = g["high"][m], g["low"][m], g["close"][m]
        if hi >= cur:
            return close_rest(cur * (1 + EXIT_SLIP), "stop" if not tp else "runner_stop", "klines")
        if not tp and lo < target:
            tp = True
            pnl += 0.75 * (E - target) - 0.75 * target * MAKER
            low_ask = cl
        if tp:
            low_ask = min(low_ask, cl)
            nxt = min(stop, be, low_ask * 1.0075)
            if cl >= nxt:
                return close_rest(cl, "runner_trail", "klines")
            cur = min(cur, nxt)
        else:
            net_ = (E - cl) - E * FEE - cl * (FEE + EXIT_SLIP)
            if net_ >= 0.5 * r and cl < be and be < cur:
                cur = be
        m += 1
    return close_rest(g["close"][m - 1], "max_hold", "klines")


# ------------------------------------------------------------- one coin-day

def replay_day(zip_path, cand_minutes, btc, funding, kl):
    windows = merge([(m - 180_000, m + 120_000) for m in cand_minutes])
    det, sigs, win_i, last_t = None, [], 0, None
    for b in iter_windows(zip_path, windows):
        ids, ts, ps, qs, ss = b["id"].tolist(), b["t"].tolist(), b["p"].tolist(), b["q"].tolist(), b["sell"].tolist()
        for k in range(len(ts)):
            t = ts[k]
            while win_i < len(windows) and t > windows[win_i][1]:
                win_i += 1
                det = None
            if det is None:
                det = Detector()
            sg = det.ingest(ids[k], t, ps[k], qs[k], ss[k], btc_ok(btc, t))
            if sg:
                sigs.append(sg)
    if not sigs:
        return [], 0
    # second pass: trades from each signal to +60 min
    tr2 = read_windows(zip_path, merge([(s["t"], s["t"] + LAT_MS + TRADE_HORIZON_MS) for s in sigs]))
    out = []
    for s in sigs:
        rec = dict(t_signal=s["t"], resistance=s["resistance"], signal_bid=s["entry"], gain=s["gain"])
        i = np.searchsorted(tr2["t"], s["t"] + LAT_MS)
        j = i
        while j < len(tr2["t"]) and not tr2["sell"][j]:
            j += 1
        if j >= len(tr2["t"]) or tr2["t"][j] - s["t"] > 10000:
            out.append(dict(rec, status="no_fill_within_10s"))
            continue
        bid = float(tr2["p"][j])
        ask = bid
        for q in range(j - 1, max(-1, j - 500), -1):
            if tr2["t"][j] - tr2["t"][q] > 5000:
                break
            if not tr2["sell"][q]:
                ask = max(bid, float(tr2["p"][q]))
                break
        stop = s["resistance"] * 1.003
        reason = None
        if (ask / bid - 1) * 10000 > 10:
            reason = "spread > 10 bps"
        elif abs(bid / s["price"] - 1) > 0.0015:
            reason = "moved > 0.15% since alert"
        elif 1 - bid / s["resistance"] > 0.01:
            reason = "> 1% below failed high"
        elif not stop > ask:
            reason = "invalidation reached"
        else:
            ok, why = entry_quality(bid, stop, s["price"])
            if not ok:
                reason = why
        fr = funding_gate(funding, s["t"])
        if reason is None and fr:
            reason = fr
        if reason:
            out.append(dict(rec, status="skipped: " + reason))
            continue
        res = manage(s, tr2, j, bid, stop, kl)
        if res is None:
            out.append(dict(rec, status="unresolved (data gap)"))
            continue
        out.append(dict(rec, status="traded", entry=bid, stop=stop, **res))
    return out, len(sigs)


def btc_ok(btc, t):
    if btc is None:
        return False
    m = (t - btc["t0"]) // MIN
    if m < 16 or m >= btc["n"]:
        return False
    c = btc["close"]
    r15 = c[m - 1] / c[m - 16] - 1
    r1 = c[m - 1] / c[m - 2] - 1
    if not (np.isfinite(r15) and np.isfinite(r1)):
        return False
    return not (r1 > 0.001 or r15 > 0)


def funding_gate(funding, t):
    if funding is None or not len(funding[0]):
        return None
    ft, fr = funding
    k = np.searchsorted(ft, t, side="right")
    if k > 0 and abs(fr[k - 1]) >= 0.0008:
        return "extreme funding"
    if k < len(ft) and ft[k] - t <= 15 * MIN:
        return "funding settlement near"
    return None


# ------------------------------------------------------------- driver

def candidate_minutes(g):
    """Minute open times where a 2% rise inside 30 seconds was possible."""
    hi = np.where(g["missing"], -np.inf, g["high"])
    lo = np.where(g["missing"], np.inf, g["low"])
    idx = np.flatnonzero(np.maximum(hi[1:], hi[:-1]) >= np.minimum(lo[1:], lo[:-1]) * 1.02) + 1
    return g["t0"] + idx * MIN


def candidates(settings, months, log=print):
    """(symbol, UTC day, number of candidate minutes) for every candidate coin-day."""
    sym_l, day_l, n_l = [], [], []
    syms = [p for p in sorted(os.listdir(os.path.join(settings.data_dir, "klines", settings.interval)))
            if p != "BTCUSDT"]
    for i, sym in enumerate(syms, 1):
        g = scan.load_grid(settings, sym, months, purpose="fade-replay-candidates")
        if g is None or g["n"] < 3:
            continue
        days = candidate_minutes(g) // 86_400_000
        u, c = np.unique(days, return_counts=True)
        sym_l += [sym] * len(u)
        day_l += u.tolist()
        n_l += c.tolist()
        if i % 100 == 0:
            log(f"fade replay candidates: {i}/{len(syms)} symbols")
    return sym_l, day_l, n_l


def run(manifest, settings, months=scan.DEV_MONTHS, n_days=250, seed=31, log=print):
    for m in months:
        if m in settings.holdout_months:
            raise holdout.HoldoutLocked(f"fade replay refuses holdout month {m}")
    out_dir = os.path.join(settings.root, "fade_replay", f"{months[0]}_{months[-1]}")
    os.makedirs(out_dir, exist_ok=True)
    cpath = os.path.join(out_dir, "candidates.parquet")
    if not os.path.exists(cpath):
        log("fade replay: scanning 1m data for candidate coin-days")
        sym_l, day_l, n_l = candidates(settings, months, log)
        pq.write_table(pa.table({"symbol": sym_l, "day": pa.array(day_l, pa.int64()),
                                 "n_minutes": pa.array(n_l, pa.int64())}), cpath)
    ct = pq.read_table(cpath).to_pylist()
    log(f"fade replay: {len(ct)} candidate coin-days")
    rng = np.random.default_rng(seed)
    pick = [ct[i] for i in rng.choice(len(ct), size=min(n_days, len(ct)), replace=False)]
    btc = scan.load_grid(settings, "BTCUSDT", months, purpose="fade-replay-btc")
    rpath = os.path.join(out_dir, "results.parquet")
    done = pq.read_table(rpath).to_pylist() if os.path.exists(rpath) else []
    seen = {(d["symbol"], d["day"]) for d in done}
    tmp = os.path.join(out_dir, "tmp")
    os.makedirs(tmp, exist_ok=True)
    grids = {}
    for i, c in enumerate(pick, 1):
        sym, day = c["symbol"], c["day"]
        if (sym, day) in seen:
            continue
        klines.check_disk(settings.root, settings.min_free_gb)
        iso = str(np.datetime64(day, "D"))
        zp = os.path.join(tmp, f"{sym}-{iso}.zip")
        base = dict(symbol=sym, day=day, n_candidate_minutes=c["n_minutes"])
        try:
            _download(aggtrades_url(sym, iso), zp, timeout=300)
            if sym not in grids:
                grids.clear()
                grids[sym] = scan.load_grid(settings, sym, months, purpose="fade-replay-exits")
            fp = os.path.join(settings.data_dir, "funding", f"{sym}.parquet")
            funding = None
            if os.path.exists(fp):
                ft = pq.read_table(fp)
                funding = (ft.column("funding_time").to_numpy(), ft.column("funding_rate").to_numpy())
            g = grids[sym]
            cm = candidate_minutes(g)
            cm = cm[(cm // 86_400_000) == day].tolist()
            recs, nsig = replay_day(zp, cm, btc, funding, (g, None))
            if not recs:
                done.append(dict(base, status="no_signal"))
            for r in recs:
                done.append(dict(base, **r))
        except net.NotFound:
            done.append(dict(base, status="aggtrades_missing"))
        except Exception as e:  # recorded, never fatal
            done.append(dict(base, status=f"error: {e!r}"[:200]))
        finally:
            if os.path.exists(zp):
                os.remove(zp)
        if i % 10 == 0 or i == len(pick):
            keys = sorted({k for d in done for k in d})
            pq.write_table(pa.table({k: [d.get(k) for d in done] for k in keys}), rpath + ".tmp")
            os.replace(rpath + ".tmp", rpath)
            log(f"fade replay: {i}/{len(pick)} coin-days")
    return out_dir


def report(settings, months=scan.DEV_MONTHS):
    out_dir = os.path.join(settings.root, "fade_replay", f"{months[0]}_{months[-1]}")
    ct = pq.read_table(os.path.join(out_dir, "candidates.parquet"), columns=["symbol"]).num_rows
    rs = pq.read_table(os.path.join(out_dir, "results.parquet")).to_pylist()
    days = {(r["symbol"], r["day"]) for r in rs}
    bad_days = {(r["symbol"], r["day"]) for r in rs if str(r.get("status", "")).startswith(("error", "aggtrades"))}
    good_days = len(days - bad_days)
    status = collections.Counter(r["status"] for r in rs if r["status"] != "no_signal")
    trades = [r for r in rs if r["status"] == "traded"]
    L = []
    P = L.append
    P(f"FADE SPIKE-MODE REPLAY (live v6.9.47 rules)  months {months[0]}..{months[-1]}")
    P(f"candidate coin-days in universe: {ct}; replayed: {good_days} (+{len(bad_days)} unavailable)")
    P("signal outcomes:")
    for k, v in status.most_common():
        P(f"  {v:5d}  {k}")
    if not trades:
        P("no executed trades")
        return "\n".join(L)
    R = np.array([t["R"] for t in trades])
    pct = np.array([t["pnl"] / t["entry"] for t in trades])
    wins = R > 0
    gw, gl = R[wins].sum(), -R[~wins].sum()
    dayk = np.array([t["symbol"] + str(t["day"]) for t in trades])
    uniq, inv = np.unique(dayk, return_inverse=True)
    sums, cnts = np.bincount(inv, weights=R), np.bincount(inv)
    rng = np.random.default_rng(5)
    boots = [sums[k].sum() / cnts[k].sum() for k in (rng.integers(0, len(uniq), len(uniq)) for _ in range(3000))]
    lo, hi = np.percentile(boots, [2.5, 97.5])
    P(f"\nEXECUTED TRADES: {len(R)}  (from {len(uniq)} coin-days)")
    P(f"  win rate {wins.mean()*100:.1f}%   avg R {R.mean():+.3f}  (95% CI {lo:+.3f} to {hi:+.3f}, day bootstrap)")
    P(f"  median R {np.median(R):+.3f}   profit factor {gw/gl if gl else float('inf'):.2f}")
    P(f"  avg net per trade {pct.mean()*100:+.3f}% of entry price; worst R {R.min():+.2f}, best R {R.max():+.2f}")
    ex = collections.Counter(t["reason"] for t in trades)
    P("  exits: " + ", ".join(f"{k} {v}" for k, v in ex.most_common()))
    P(f"  reached 75% target: {np.mean([bool(t['tp']) for t in trades])*100:.1f}%;  "
      f"resolved on trade data {np.mean([t['resolved']=='trades' for t in trades])*100:.0f}%")
    stops = [t for t in trades if t["reason"] == "stop"]
    if stops:
        sl = np.array([t["exit_px"] / t["stop"] - 1 for t in stops])
        P(f"  stop fills vs stop level: median {np.median(sl)*100:+.3f}%, 90th pct {np.percentile(sl,90)*100:+.3f}%")
    per_day = len(R) / max(1, good_days)
    nmon = len(months)
    P(f"\nestimated universe-wide trades/month (before unmodelled gates): "
      f"{per_day * ct / nmon:.0f}  ({per_day:.2f} per candidate coin-day)")
    P("Live comparison: spike mode traded 15 times in ~11 days of October (with all gates).")
    text = "\n".join(L)
    with open(os.path.join(out_dir, "REPORT_FADE.txt"), "w") as f:
        f.write(text + "\n")
    return text
