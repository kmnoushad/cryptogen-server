"""Fade replay tests: detector port, entry quality, exits, aggTrades streaming."""
import os
import tempfile
import unittest
import zipfile

import numpy as np

from ghr import fade_replay as fr

T0 = 1_760_000_000_000


def spike_stream(btc_gate=True, crash=False):
    """150 s quiet at 1.00, 20 s ramp to 1.03 on heavy buying, then a 0.6% pullback on selling."""
    rows, tid, t = [], 0, T0
    def add(px, q, sell):
        nonlocal tid
        tid += 1
        rows.append((tid, t, px, q, sell))
    for _ in range(750):                       # 150 s, one trade every 200 ms
        add(1.0 if tid % 2 else 1.0005, 10, tid % 2 == 0)
        t += 200
    for k in range(100):                       # 20 s ramp, heavy buys
        add(1.0 + 0.03 * (k + 1) / 100, 400, False)
        t += 200
    peak = 1.03
    target = peak * (0.99 if crash else 0.994)
    for k in range(40):                        # 8 s of selling down to the pullback level
        px = peak - (peak - target) * min(1, (k + 1) / 10)
        add(px, 300, True)
        if k % 5 == 4:
            add(px * 1.0004, 20, False)        # occasional buy keeps the ask proxy fresh
        t += 200
    return rows


def feed(rows, btc=True):
    d, out = fr.Detector(), []
    for r in rows:
        s = d.ingest(*r, btc)
        if s:
            out.append(s)
    return out


class TestDetector(unittest.TestCase):
    def test_candidate_on_spike_and_rejection(self):
        sigs = feed(spike_stream())
        self.assertEqual(len(sigs), 1)
        s = sigs[0]
        self.assertAlmostEqual(s["resistance"], 1.03)
        self.assertGreaterEqual(s["gain"], 0.02)
        self.assertLessEqual(1 - s["entry"] / s["resistance"], 0.009)

    def test_btc_gate_blocks(self):
        self.assertEqual(feed(spike_stream(), btc=False), [])

    def test_no_chasing_after_deep_fade(self):
        self.assertEqual(feed(spike_stream(crash=True)), [])

    def test_quiet_market_no_signal(self):
        rows = [(i + 1, T0 + i * 200, 1.0 + 0.0001 * (i % 3), 5, i % 2 == 0) for i in range(3000)]
        self.assertEqual(feed(rows), [])


class TestEntryQuality(unittest.TestCase):
    def test_matches_js_formula(self):
        ok, _ = fr.entry_quality(1.0, 1.01, 1.0)
        self.assertTrue(ok)
        ok, why = fr.entry_quality(1.0, 1.003, 1.0)    # costs 33% of a 0.3% stop
        self.assertFalse(ok)
        ok, why = fr.entry_quality(0.99, 1.01, 1.0)    # sold 1% below the alert: chasing
        self.assertFalse(ok)
        self.assertIn("chase", why)


def trades(seq, t0=T0):
    ids = np.arange(1, len(seq) + 1)
    t = np.array([t0 + i * 1000 for i in range(len(seq))], np.int64)
    return {"id": ids, "t": t, "p": np.array([s[0] for s in seq], float),
            "q": np.ones(len(seq)), "sell": np.array([s[1] for s in seq], bool)}


class TestManage(unittest.TestCase):
    def test_stop_fills_at_next_buy(self):
        tr = trades([(1.0, True), (1.005, False), (1.0125, True), (1.013, False)])
        res = fr.manage({}, tr, 0, 1.0, 1.012)
        self.assertEqual(res["reason"], "stop")
        self.assertAlmostEqual(res["exit_px"], 1.013)
        self.assertLess(res["R"], -1.0)

    def test_target_then_runner_trail(self):
        E, stop = 1.0, 1.012
        r = stop * (1 + fr.FEE + fr.EXIT_SLIP) - E * (1 - fr.FEE)
        target = (E - (1.5 * r + E * fr.FEE) / 0.75) / (1 + fr.FEE)
        seq = [(1.0, True)] + [(1.0 - 0.001 * k, k % 2 == 0) for k in range(1, 40)]
        low = seq[-1][0]
        seq += [(low * (1 + 0.002 * k), False) for k in range(1, 15)]
        res = fr.manage({}, trades(seq), 0, E, stop)
        self.assertTrue(res["tp"])
        self.assertLess(target, 0.98)
        self.assertTrue(res["reason"].startswith("runner"))
        self.assertGreater(res["R"], 1.0)

    def test_break_even_move(self):
        E, stop = 1.0, 1.012
        seq = [(1.0, True)] + [(0.99, False)] * 8 + [(1.0, False)] * 3
        res = fr.manage({}, trades(seq), 0, E, stop)
        self.assertEqual(res["reason"], "stop")
        self.assertTrue(res["be_moved"])
        self.assertGreater(res["R"], -0.3)

    def test_unresolved_without_klines(self):
        tr = trades([(1.0, True), (1.001, False)])
        self.assertIsNone(fr.manage({}, tr, 0, 1.0, 1.012))


class TestIO(unittest.TestCase):
    def write(self, d, header):
        rows = ["agg_trade_id,price,quantity,first_trade_id,last_trade_id,transact_time,is_buyer_maker"] if header else []
        for i in range(1000):
            rows.append(f"{i+1},{1+i*1e-4},1,{i+1},{i+1},{T0 + i*1000},{'true' if i % 2 else 'false'}")
        zp = os.path.join(d, f"x{header}.zip")
        with zipfile.ZipFile(zp, "w") as z:
            z.writestr("X-aggTrades.csv", "\n".join(rows) + "\n")
        return zp

    def test_windows_with_and_without_header(self):
        with tempfile.TemporaryDirectory() as d:
            for header in (True, False):
                tr = fr.read_windows(self.write(d, header), [(T0 + 10_000, T0 + 19_000), (T0 + 500_000, T0 + 500_000)])
                self.assertEqual(len(tr["t"]), 11)
                self.assertEqual(tr["id"][0], 11)
                self.assertFalse(tr["sell"][0])   # row 11 (i=10) is a taker buy
                self.assertTrue(tr["sell"][1])


class TestGates(unittest.TestCase):
    def test_funding_gate(self):
        ft = np.array([T0, T0 + 8 * 3600_000])
        rate = np.array([0.0009, 0.0001])
        self.assertEqual(fr.funding_gate((ft, rate), T0 + 3600_000), "extreme funding")
        self.assertEqual(fr.funding_gate((ft, np.array([0.0001, 0.0001])), T0 + 8 * 3600_000 - 10 * 60_000),
                         "funding settlement near")
        self.assertIsNone(fr.funding_gate((ft, np.array([0.0001, 0.0001])), T0 + 3600_000))

    def test_btc_gate(self):
        n = 100
        c = np.ones(n)
        btc = {"t0": T0, "n": n, "close": c}
        self.assertTrue(fr.btc_ok(btc, T0 + 50 * 60_000))
        c2 = c.copy()
        c2[30:] = 1.01
        self.assertFalse(fr.btc_ok({"t0": T0, "n": n, "close": c2}, T0 + 40 * 60_000))


class TestEndToEnd(unittest.TestCase):
    def test_replay_day(self):
        rows = spike_stream()
        last_t = rows[-1][1]
        tid = rows[-1][0]
        for k in range(1, 400):   # after the signal: price slides lower, mixed flow
            tid += 1
            rows.append((tid, last_t + k * 1000, 1.023 - 0.0002 * k, 5, k % 2 == 0))
        low = rows[-1][2]
        for k in range(1, 60):    # then rebounds, which ends the runner
            tid += 1
            rows.append((tid, last_t + (400 + k) * 1000, low * (1 + 0.001 * k), 5, False))
        with tempfile.TemporaryDirectory() as d:
            zp = os.path.join(d, "a.zip")
            with zipfile.ZipFile(zp, "w") as z:
                z.writestr("A-aggTrades.csv", "\n".join(
                    f"{r[0]},{r[2]},{r[3]},{r[0]},{r[0]},{r[1]},{'true' if r[4] else 'false'}" for r in rows) + "\n")
            n = 200
            btc = {"t0": T0 - 100 * 60_000, "n": n, "close": np.ones(n)}
            cand = [T0 + 150_000]
            recs, nsig = fr.replay_day(zp, cand, btc, None, None)
        self.assertEqual(nsig, 1)
        self.assertEqual(len(recs), 1)
        self.assertEqual(recs[0]["status"], "traded")
        self.assertTrue(recs[0]["tp"])
        self.assertGreater(recs[0]["R"], 1.0)


if __name__ == "__main__":
    unittest.main()
