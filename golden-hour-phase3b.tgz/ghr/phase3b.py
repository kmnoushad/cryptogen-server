"""Phase 3b (pre-registered 16 Oct 2026, development months only).

A. CONTROLS. For every trigger, 2 random entry minutes on the same symbol and
   same UTC day, and 2 on the same symbol at random across the whole period.
   Same outcome measurements. If triggers do no better than random entries,
   they detect nothing.
B. TAILS. Means and 5th/95th percentiles, not only medians.
C. CRUDE BRACKETS. From the next minute's open: take-profit / stop pairs
   (+10%/-5%) and (+20%/-10%) within 24h; neither hit = exit at the 24h close.
   A minute that touches both counts as the STOP (conservative). Stops fill at
   the stop price, which is optimistic in fast markets; ~0.2% round-trip cost is
   shown separately. This is a screening tool, not a backtest.
D. TIME OF DAY. Pooled triggers (deduped 1 per symbol per 60 min) split into
   08:30-10:30 NY on US trading days, 23:30-00:30 UTC, and everything else.
   Compares follow-through quality, with a day-block bootstrap.
E. EXHAUSTION (SHORT side, causal). An episode starts the first minute a coin's
   close is >= E above its lowest low of the previous 24h (E in {50%, 100%};
   24h refractory). Entry variants: D=0 (at the cross), or the first close that
   is >= D below the highest high since the episode began (D in {10%, 20%},
   searched up to 48h). Short brackets mirror C. Squeeze = highest high after
   entry. Only past data defines every entry.
"""
import os

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

from . import holdout, scan

MIN = scan.MIN
DAY = scan.DAY
BRACKETS = ((0.10, 0.05), (0.20, 0.10))
EXT = (0.50, 1.00)
DROPS = (0.0, 0.10, 0.20)
K_SAME_DAY = 2
K_ANY = 2


def bwd_min(a, w):
    return scan.fwd_min(a[::-1], w)[::-1]


def bwd_count(mask, w):
    return scan.fwd_count(mask[::-1], w)[::-1]


def first_touch(g, t, up, dn, side=1):
    """Signal at minute t, entry at open[t+1]. side=1 long, -1 short.
    Returns (code, realised): code 1 target first, -1 stop first, 0 neither;
    realised return in the trade's direction. None if the window is incomplete."""
    n = g["n"]
    e0, e1 = t + 1, t + 1 + DAY
    if e1 > n or g["missing"][e0:e1].any():
        return None
    entry = g["open"][e0]
    hi, lo = g["high"][e0:e1], g["low"][e0:e1]
    if side == 1:
        hit_t = np.flatnonzero(hi >= entry * (1 + up))
        hit_s = np.flatnonzero(lo <= entry * (1 - dn))
    else:
        hit_t = np.flatnonzero(lo <= entry * (1 - up))
        hit_s = np.flatnonzero(hi >= entry * (1 + dn))
    it = hit_t[0] if len(hit_t) else 10**9
    is_ = hit_s[0] if len(hit_s) else 10**9
    if is_ <= it and is_ < 10**9:
        return -1, -dn
    if it < 10**9:
        return 1, up
    close = g["close"][e1 - 1]
    return 0, side * (close / entry - 1)


def outcomes(g, t, side=1):
    """Common outcome set for one signal minute. None if incomplete."""
    n = g["n"]
    e0, e1 = t + 1, t + 1 + DAY
    if e1 > n or g["missing"][e0:e1].any():
        return None
    entry = g["open"][e0]
    hi, lo, cl = g["high"][e0:e1], g["low"][e0:e1], g["close"]
    r = dict(entry=float(entry),
             ret_240=float(side * (cl[t + 240] / entry - 1)),
             ret_1440=float(side * (cl[e1 - 1] / entry - 1)),
             mfe_1440=float(hi.max() / entry - 1),   # highest point (squeeze for shorts)
             mae_1440=float(lo.min() / entry - 1))
    for up, dn in BRACKETS:
        code, real = first_touch(g, t, up, dn, side)
        tag = f"{int(up*100)}_{int(dn*100)}"
        r[f"br{tag}_code"] = code
        r[f"br{tag}_ret"] = float(real)
    return r


def controls_for(g, trig, rng):
    """Random entry minutes for each (variant, t): same UTC day, and anywhere in the period."""
    n = g["n"]
    day0 = (g["t0"] // MIN) % DAY  # minute-of-day of index 0
    out = []
    valid_max = n - DAY - 2
    if valid_max <= 0:
        return out
    for variant, t in trig:
        d_start = t - ((day0 + t) % DAY)
        lo_i, hi_i = max(0, d_start), min(valid_max, d_start + DAY - 1)
        for _ in range(K_SAME_DAY):
            if hi_i > lo_i:
                out.append((variant, "same_day", int(rng.integers(lo_i, hi_i + 1))))
        for _ in range(K_ANY):
            out.append((variant, "any_day", int(rng.integers(0, valid_max + 1))))
    return out


def exhaustion_signals(g):
    """Causal short-entry candidates. Returns list of (E, D, episode_start, entry_minute)."""
    n = g["n"]
    lo = np.where(g["missing"], np.inf, g["low"])
    hi = np.where(g["missing"], -np.inf, g["high"])
    low24 = bwd_min(lo, DAY + 1)              # lowest low over [t-24h, t]
    gaps = bwd_count(g["missing"], DAY + 1)
    gain = g["close"] / low24 - 1
    ok = (gaps == 0) & np.isfinite(gain) & (np.arange(n) >= DAY)
    sigs = []
    for E in EXT:
        cand = np.flatnonzero(ok & (gain >= E))
        last = -10**9
        for s0 in cand:
            if s0 - last < DAY:
                continue
            last = s0
            for D in DROPS:
                if D == 0.0:
                    sigs.append((E, D, int(s0), int(s0)))
                    continue
                end = min(n, s0 + 2 * DAY)
                seg_hi = np.maximum.accumulate(hi[s0:end])
                seg_cl = g["close"][s0:end]
                hit = np.flatnonzero(seg_cl <= seg_hi * (1 - D))
                if len(hit) and not g["missing"][s0:s0 + hit[0] + 1].any():
                    sigs.append((E, D, int(s0), int(s0 + hit[0])))
    return sigs


def _write(rows, path):
    return scan.write_rows(rows, path)


def run(manifest, settings, months=scan.DEV_MONTHS, log=print, symbols=None, seed=11):
    for m in months:
        if m in settings.holdout_months:
            raise holdout.HoldoutLocked(f"phase3b refuses holdout month {m}")
    out_dir = os.path.join(settings.root, "phase3b", f"{months[0]}_{months[-1]}")
    sym_rows = manifest.db.execute(
        "SELECT symbol, first_month, last_month FROM symbols WHERE in_archive=1 ORDER BY symbol").fetchall()
    if symbols:
        sym_rows = [r for r in sym_rows if r[0] in symbols]
    sym_rows = [r for r in sym_rows if r[1] and r[1] <= months[-1] and (r[2] or r[1]) >= months[0]]
    rng = np.random.default_rng(seed)
    totals = dict(trig=0, ctrl=0, exh=0)
    for i, (sym, _, _) in enumerate(sym_rows, 1):
        g = scan.load_grid(settings, sym, months, purpose="phase3b-dev")
        if g is None:
            continue
        trows, tminutes = [], []
        for r in scan.triggers(g, sym):
            t = (r["t_ms"] - g["t0"]) // MIN
            o = outcomes(g, t, side=1)
            if o is None:
                continue
            trows.append(dict(symbol=sym, variant=r["variant"], t_ms=r["t_ms"], **o))
            tminutes.append((r["variant"], t))
        crows = []
        for variant, kind, t in controls_for(g, tminutes, rng):
            o = outcomes(g, t, side=1)
            if o is not None:
                crows.append(dict(symbol=sym, variant=variant, kind=kind,
                                  t_ms=g["t0"] + t * MIN, **o))
        erows = []
        for E, D, s0, t in exhaustion_signals(g):
            o = outcomes(g, t, side=-1)
            if o is None:
                continue
            erows.append(dict(symbol=sym, variant=f"E{int(E*100)}_D{int(D*100)}",
                              episode_ms=g["t0"] + s0 * MIN, t_ms=g["t0"] + t * MIN, **o))
        totals["trig"] += _write(trows, os.path.join(out_dir, "triggers", f"{sym}.parquet"))
        totals["ctrl"] += _write(crows, os.path.join(out_dir, "controls", f"{sym}.parquet"))
        totals["exh"] += _write(erows, os.path.join(out_dir, "exhaustion", f"{sym}.parquet"))
        if i % 50 == 0:
            log(f"phase3b: {i}/{len(sym_rows)} symbols {totals}")
    log(f"phase3b finished: {len(sym_rows)} symbols {totals} -> {out_dir}")
    return out_dir
