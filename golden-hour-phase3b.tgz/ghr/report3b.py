"""Phase 3b report. Development months only; screening statistics, not a backtest."""
import glob
import warnings
import os

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

from . import report3

warnings.filterwarnings("ignore", category=RuntimeWarning)
COST = 0.002  # rough round trip: 2 x 0.05% taker + slippage allowance
MIN = 60_000


def load(out_dir, sub, cols):
    files = sorted(glob.glob(os.path.join(out_dir, sub, "*.parquet")))
    if not files:
        return None
    t = pa.concat_tables([pq.read_table(f, columns=cols) for f in files])
    d = {}
    for c in cols:
        col = t.column(c)
        if pa.types.is_string(col.type) or pa.types.is_large_string(col.type):
            enc = col.combine_chunks().dictionary_encode()
            d[c] = (enc.indices.to_numpy(), enc.dictionary.to_pylist())
        else:
            d[c] = col.to_numpy(zero_copy_only=False).astype(float) if c != "t_ms" else col.to_numpy()
    return d


def codes(d, c, value):
    idx, labels = d[c]
    return idx == labels.index(value) if value in labels else np.zeros(len(idx), bool)


def pct(x):
    return "  n/a" if x is None or not np.isfinite(x) else f"{x*100:5.1f}%"


def boot_ci(values, day_ids, n_boot=2000, seed=3):
    """Day-block bootstrap 95% CI of the mean."""
    if len(values) < 10:
        return (np.nan, np.nan)
    days, inv = np.unique(day_ids, return_inverse=True)
    sums = np.bincount(inv, weights=values)
    cnts = np.bincount(inv)
    rng = np.random.default_rng(seed)
    nd = len(days)
    b = []
    for _ in range(n_boot):
        k = rng.integers(0, nd, nd)
        c = cnts[k].sum()
        if c:
            b.append(sums[k].sum() / c)
    return tuple(np.percentile(b, [2.5, 97.5])) if b else (np.nan, np.nan)


def vsort(labels):
    def key(s):
        return tuple(int("".join(ch for ch in part if ch.isdigit()) or 0) for part in s.split("_"))
    return sorted(labels, key=key)


def report(out_dir):
    L = []
    P = L.append
    P(f"PHASE 3B REPORT  ({out_dir})")
    P("Development months only. Screening statistics, NOT a backtest.")
    P("Brackets: same-minute double touch = stop; stops fill at stop price (optimistic).")
    P(f"'net' = mean minus {COST*100:.1f}% rough round-trip cost.\n")

    cols = ["symbol", "variant", "t_ms", "ret_240", "ret_1440", "mfe_1440", "mae_1440",
            "br10_5_ret", "br20_10_ret"]
    T = load(out_dir, "triggers", cols)
    C = load(out_dir, "controls", cols + ["kind"])
    if T is None:
        P("no trigger outcomes found")
        return "\n".join(L)
    tv_idx, tv_lab = T["variant"]
    same = codes(C, "kind", "same_day") if C else None
    anyd = codes(C, "kind", "any_day") if C else None

    # ---- A. triggers vs random entries
    P("A. TRIGGERS vs RANDOM ENTRIES (long side, 24h window)")
    P("   T = trigger, S = random time same coin same day, A = random time same coin any day")
    P(f"{'variant':12} {'n':>6} | {'hit +20% T/S/A':^20} | {'mean 24h ret T/S/A':^22} | {'bracket 20/10 mean T/S/A':^24} | {'T net':>6}")
    for v in vsort(tv_lab):
        mt = tv_idx == tv_lab.index(v)
        cv = (C["variant"][0] == C["variant"][1].index(v)) if C and v in C["variant"][1] else None
        def stats(src, m):
            if m is None or not m.any():
                return (np.nan, np.nan, np.nan)
            return ((src["mfe_1440"][m] >= 0.2).mean(), src["ret_1440"][m].mean(), src["br20_10_ret"][m].mean())
        st = stats(T, mt)
        ss = stats(C, cv & same) if cv is not None else (np.nan,) * 3
        sa = stats(C, cv & anyd) if cv is not None else (np.nan,) * 3
        P(f"{v:12} {mt.sum():6d} | {pct(st[0])} {pct(ss[0])} {pct(sa[0])} | "
          f"{pct(st[1])} {pct(ss[1])} {pct(sa[1])} | {pct(st[2])} {pct(ss[2])} {pct(sa[2])} | {pct(st[2]-COST)}")
    P("")

    # ---- B. tails
    P("B. TAILS (triggers, long side)")
    P(f"{'variant':12} {'mean4h':>7} {'mean24h':>7} {'p5 24h':>7} {'p95 24h':>7} {'worst5% dip':>11} {'top5% run':>9} {'br10/5':>7} {'br20/10':>7}")
    for v in vsort(tv_lab):
        m = tv_idx == tv_lab.index(v)
        r24 = T["ret_1440"][m]
        P(f"{v:12} {pct(T['ret_240'][m].mean()):>7} {pct(r24.mean()):>7} {pct(np.percentile(r24, 5)):>7} "
          f"{pct(np.percentile(r24, 95)):>7} {pct(np.percentile(T['mae_1440'][m], 5)):>11} "
          f"{pct(np.percentile(T['mfe_1440'][m], 95)):>9} {pct(T['br10_5_ret'][m].mean()):>7} "
          f"{pct(T['br20_10_ret'][m].mean()):>7}")
    P("")

    # ---- C. time of day (pooled, deduped)
    s_idx, _ = T["symbol"]
    keep = report3.dedupe_pooled(s_idx, T["t_ms"])
    tms = T["t_ms"][keep]
    day, minute, wd = report3.ny_parts(tms)
    kind = report3.day_kind(day, wd)
    utc_min = (tms // MIN) % 1440
    gh = (kind == "trading") & (minute >= report3.WINDOW[0]) & (minute < report3.WINDOW[1])
    u0 = (utc_min >= 1410) | (utc_min < 30)
    rest = ~gh & ~u0
    br = T["br20_10_ret"][keep]
    hit = T["mfe_1440"][keep] >= 0.2
    r4 = T["ret_240"][keep]
    uday = tms // 86_400_000
    P("C. FOLLOW-THROUGH BY TIME OF DAY (pooled triggers, 1 per coin per 60 min)")
    P(f"{'group':28} {'n':>6} {'hit+20%':>8} {'mean4h':>7} {'br20/10':>8} {'95% CI (day bootstrap)':>24}")
    for name, m in (("08:30-10:30 NY, US trading", gh), ("23:30-00:30 UTC (all days)", u0), ("everything else", rest)):
        lo, hi = boot_ci(br[m], uday[m])
        P(f"{name:28} {m.sum():6d} {pct(hit[m].mean()):>8} {pct(r4[m].mean()):>7} {pct(br[m].mean()):>8} "
          f"   ({pct(lo)}, {pct(hi)})")
    P("")

    # ---- D. exhaustion (short side)
    E = load(out_dir, "exhaustion", ["symbol", "variant", "t_ms", "ret_240", "ret_1440", "mfe_1440",
                                     "br10_5_ret", "br10_5_code", "br20_10_ret", "br20_10_code"])
    P("D. EXHAUSTION SHORTS (causal entries; returns shown from the SHORT's point of view)")
    if E is None:
        P("   no exhaustion signals")
    else:
        ev_idx, ev_lab = E["variant"]
        P(f"{'variant':9} {'n':>5} {'mean4h':>7} {'mean24h':>7} {'br10/5':>7} {'tgt1st':>7} {'br20/10':>8} {'tgt1st':>7} "
          f"{'net20/10':>8} {'95% CI':>17} {'sq>=20%':>8} {'sq>=50%':>8} {'p95 sq':>7}")
        for v in vsort(ev_lab):
            m = ev_idx == ev_lab.index(v)
            b = E["br20_10_ret"][m]
            lo, hi = boot_ci(b, E["t_ms"][m] // 86_400_000)
            sq = E["mfe_1440"][m]
            P(f"{v:9} {m.sum():5d} {pct(E['ret_240'][m].mean()):>7} {pct(E['ret_1440'][m].mean()):>7} "
              f"{pct(E['br10_5_ret'][m].mean()):>7} {pct((E['br10_5_code'][m] == 1).mean()):>7} "
              f"{pct(b.mean()):>8} {pct((E['br20_10_code'][m] == 1).mean()):>7} {pct(b.mean()-COST):>8} "
              f"({pct(lo)},{pct(hi)}) {pct((sq >= .2).mean()):>8} {pct((sq >= .5).mean()):>8} "
              f"{pct(np.percentile(sq, 95)):>7}")
        P("   E50/E100 = coin up >=50%/100% vs its 24h low; D0 = enter at that moment,")
        P("   D10/D20 = enter at the first close 10%/20% below the high since then (within 48h).")
        P("   sq = squeeze: highest price within 24h after entry, i.e. how far it ran against the short.")
    text = "\n".join(L)
    with open(os.path.join(out_dir, "REPORT_3B.txt"), "w") as f:
        f.write(text + "\n")
    return text
