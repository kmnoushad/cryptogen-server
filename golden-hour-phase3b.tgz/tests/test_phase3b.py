"""Phase 3b tests: bracket conservatism, causality of exhaustion entries, controls."""
import os
import tempfile
import unittest

import numpy as np

from ghr import holdout, klines, phase3b, report3b, scan
from ghr.config import Settings
from ghr.manifest import Manifest
from test_phase3 import OCT, MIN, TestTriggers, grid_from


class TestBrackets(unittest.TestCase):
    def test_double_touch_counts_as_stop(self):
        p = np.ones(3000)
        g = grid_from(p)
        g["high"][101] = 1.5   # same minute hits +20% target and -10% stop
        g["low"][101] = 0.85
        self.assertEqual(phase3b.first_touch(g, 99, 0.20, 0.10, 1), (-1, -0.10))

    def test_target_first_long_and_short(self):
        p = np.ones(3000)
        p[150:] = 1.3
        g = grid_from(p)
        self.assertEqual(phase3b.first_touch(g, 99, 0.20, 0.10, 1), (1, 0.20))
        self.assertEqual(phase3b.first_touch(g, 99, 0.20, 0.10, -1), (-1, -0.10))

    def test_neither_exits_at_24h_close(self):
        g = grid_from(np.ones(3000))
        code, real = phase3b.first_touch(g, 99, 0.20, 0.10, 1)
        self.assertEqual(code, 0)
        self.assertAlmostEqual(real, 0.0)

    def test_incomplete_window_is_none(self):
        g = grid_from(np.ones(1500))
        self.assertIsNone(phase3b.first_touch(g, 99, 0.2, 0.1, 1))
        g = grid_from(np.ones(3000))
        g["missing"][500] = True
        self.assertIsNone(phase3b.outcomes(g, 99))


class TestExhaustion(unittest.TestCase):
    def series(self):
        flat = [1.0] * 2000
        up = list(np.linspace(1.0, 2.2, 300))
        top = [2.2] * 60
        down = list(np.linspace(2.2, 1.4, 600))
        return np.array(flat + up + top + down + [1.4] * 3000)

    def test_signals_found_and_ordered(self):
        sigs = phase3b.exhaustion_signals(grid_from(self.series()))
        kinds = {(E, D) for E, D, _, _ in sigs}
        self.assertIn((0.5, 0.0), kinds)
        self.assertIn((1.0, 0.2), kinds)
        for E, D, s0, t in sigs:
            self.assertGreaterEqual(t, s0)

    def test_causal(self):
        p = self.series()
        full = phase3b.exhaustion_signals(grid_from(p))
        for E, D, s0, t in full:
            trunc = phase3b.exhaustion_signals(grid_from(p[:t + 1]))
            self.assertIn((E, D, s0, t), trunc, "entry depends on future data")


class TestControls(unittest.TestCase):
    def test_same_day_on_same_utc_day(self):
        g = grid_from(np.ones(10 * 1440))
        rng = np.random.default_rng(0)
        trig = [("v", 3 * 1440 + 700)]
        out = phase3b.controls_for(g, trig, rng)
        same = [t for v, k, t in out if k == "same_day"]
        self.assertEqual(len(same), phase3b.K_SAME_DAY)
        self.assertTrue(all(t // 1440 == 3 for t in same))


class TestEndToEnd(unittest.TestCase):
    def test_run_and_report(self):
        with tempfile.TemporaryDirectory() as d:
            st = Settings(root=d)
            os.makedirs(st.data_dir)
            mf = Manifest(st.manifest_path)
            p, v = TestTriggers().series()
            p = p.copy()
            n = len(p)
            cols = {"open_time": [OCT + i * MIN for i in range(n)], "open": list(p),
                    "high": list(p * 1.001), "low": list(p * 0.999), "close": list(p),
                    "volume": list(v / p), "close_time": [OCT + i * MIN + 59999 for i in range(n)],
                    "quote_volume": list(v), "trades": [10] * n, "taker_buy_base": list(v / p / 2),
                    "taker_buy_quote": list(v / 2)}
            klines.write_parquet(cols, os.path.join(st.data_dir, "klines", "1m", "XUSDT", "2025-10.parquet"))
            mf.upsert_symbol("XUSDT", in_archive=1, first_month="2025-10", last_month="2025-10")
            out = phase3b.run(mf, st, months=("2025-10",), log=lambda *_: None)
            text = report3b.report(out)
            for h in ("A. TRIGGERS", "B. TAILS", "C. FOLLOW-THROUGH", "D. EXHAUSTION"):
                self.assertIn(h, text)
            with self.assertRaises(holdout.HoldoutLocked):
                phase3b.run(mf, st, months=("2026-07",), log=lambda *_: None)
            mf.close()


if __name__ == "__main__":
    unittest.main()
