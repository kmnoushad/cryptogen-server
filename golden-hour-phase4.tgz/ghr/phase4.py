"""Phase 4: LONG fast-move strategy (pre-registered 17 Oct 2026).

Entry: at the close of minute t, close[t] / close[t-5] - 1 >= X, X in {5%, 8%}.
       No volume filter (Phase 3b showed it adds nothing). Market buy at the
       open of minute t+1 plus measured slippage. One position per symbol;
       no re-entry on that symbol until 60 minutes after the previous exit.
Exits: initial stop S below entry, S in {5%, 8%}; trailing stop T below the
       highest high of COMPLETED minutes since entry, T in {8%, 15%}; the stop
       never moves down. A minute whose low touches the stop exits at the stop,
       or at the minute's open if it gapped through, minus measured stop
       slippage. Time exit after 24h at that minute's close minus entry-side
       slippage. A missing minute while in a trade exits at the next available
       open minus stop slippage. 2 x 2 x 2 = 8 variants. Nothing else is tuned.
Costs: taker fee each side (0.05% default), measured slippage, and historical
       funding (longs pay positive funding) for every funding time held.
Portfolio: at most K=5 open positions, risk f=0.5% of equity per trade
       (notional = f * equity / S), leverage cap 2x equity per position.
       Signals that arrive while full are skipped (counted).

Slippage (4a) is measured from Binance aggTrades on a sample of real Phase 3b
fast-move triggers: entry = first taker-BUY trade at least `latency` after the
signal minute closes, versus that minute's kline open; stop = first taker-SELL
trade at least `latency` after price first trades through entry*(1-5%), versus
that level. Results are written to slippage.parquet and summarised.
"""
import csv
import glob
import io
import json
import os
import shutil
import urllib.parse
import urllib.request
import zipfile

import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

from . import holdout, klines, net, scan
from .config import ARCHIVE_BASE

MIN = scan.MIN
DAY = scan.DAY
ENTRY_X = (0.05, 0.08)
STOPS = (0.05, 0.08)
TRAILS = (0.08, 0.15)
HOLD = DAY
REENTRY_GAP = 60
K_MAX = 5
RISK = 0.005
LEV_CAP = 2.0
FEE = 0.0005


# ---------------------------------------------------------------- 4a slippage

def _download(url, path, timeout=120):
    req = urllib.request.Request(url, headers={"User-Agent": net.UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r, open(path, "wb") as f:
            shutil.copyfileobj(r, f, 1 << 20)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise net.NotFound(url) from None
        raise


def aggtrades_url(symbol, day):
    path = f"/data/futures/um/daily/aggTrades/{symbol}/{symbol}-aggTrades-{day}.zip"
    return ARCHIVE_BASE + urllib.parse.quote(path)


def scan_trades(zip_path, t_signal_end, latencies=(1000, 3000), stop_pct=0.05, horizon_ms=DAY * MIN):
    """Stream one day of aggTrades; never loads the CSV into memory."""
    out = {f"entry_px_{l}": np.nan for l in latencies}
    out.update(stop_level=np.nan, stop_px=np.nan, stop_cross_ms=np.nan)
    with zipfile.ZipFile(zip_path) as z:
        name = [n for n in z.namelist() if n.endswith(".csv")][0]
        with z.open(name) as raw:
            rd = csv.reader(io.TextIOWrapper(raw, encoding="ascii"))
            pending = set(latencies)
            for row in rd:
                if not row or not row[0].isdigit():
                    continue
                ts = int(row[5])
                ts = ts // 1000 if ts > 10**14 else ts
                if ts < t_signal_end:
                    continue
                if ts > t_signal_end + horizon_ms:
                    break
                px = float(row[1])
                buyer_maker = row[6].strip().lower() == "true"
                for l in list(pending):
                    if ts >= t_signal_end + l and not buyer_maker:   # taker buy = lifts the ask
                        out[f"entry_px_{l}"] = px
                        pending.discard(l)
                if not pending and np.isnan(out["stop_level"]):
                    out["stop_level"] = out[f"entry_px_{latencies[0]}"] * (1 - stop_pct)
                if np.isfinite(out["stop_level"]):
                    if np.isnan(out["stop_cross_ms"]) and px <= out["stop_level"]:
                        out["stop_cross_ms"] = ts
                    if (np.isfinite(out["stop_cross_ms"]) and ts >= out["stop_cross_ms"] + latencies[0]
                            and buyer_maker):                         # taker sell = hits the bid
                        out["stop_px"] = px
                        break
    return out


def sample_slippage(manifest, settings, months=scan.DEV_MONTHS, n_events=150, seed=21, log=print):
    p3b = os.path.join(settings.root, "phase3b", f"{months[0]}_{months[-1]}", "triggers")
    files = sorted(glob.glob(os.path.join(p3b, "*.parquet")))
    if not files:
        raise RuntimeError("run scan3b first: Phase 4a samples from its fast-move triggers")
    rows = []
    for f in files:
        t = pq.read_table(f, columns=["symbol", "variant", "t_ms", "entry"])
        var = np.array(t.column("variant").to_pylist())
        m = np.isin(var, ["L5_R5_V3", "L5_R8_V3"])
        if m.any():
            sym = t.column("symbol").to_pylist()
            tms = t.column("t_ms").to_numpy()
            ent = t.column("entry").to_numpy()
            rows += [(sym[i], var[i], int(tms[i]), float(ent[i])) for i in np.flatnonzero(m)]
    rng = np.random.default_rng(seed)
    pick = [rows[i] for i in rng.choice(len(rows), size=min(n_events, len(rows)), replace=False)]
    out_dir = os.path.join(settings.root, "phase4")
    tmp = os.path.join(out_dir, "tmp")
    os.makedirs(tmp, exist_ok=True)
    path = os.path.join(out_dir, "slippage.parquet")
    done = []
    if os.path.exists(path):
        done = pq.read_table(path).to_pylist()
    seen = {(d["symbol"], d["t_ms"]) for d in done}
    for i, (sym, var, t_ms, kline_open) in enumerate(pick, 1):
        if (sym, t_ms) in seen:
            continue
        klines.check_disk(settings.root, settings.min_free_gb)
        day = np.datetime64(t_ms, "ms").astype("datetime64[D]").astype(str)
        zp = os.path.join(tmp, f"{sym}-{day}.zip")
        rec = dict(symbol=sym, variant=var, t_ms=t_ms, kline_open=kline_open, status="ok")
        try:
            _download(aggtrades_url(sym, day), zp)
            r = scan_trades(zp, t_ms + MIN)  # signal minute closes at t+1min
            rec.update(r)
        except net.NotFound:
            rec["status"] = "missing"
        except Exception as e:  # recorded, never fatal
            rec["status"] = f"error: {e!r}"[:200]
        finally:
            if os.path.exists(zp):
                os.remove(zp)
        done.append(rec)
        if i % 10 == 0 or i == len(pick):
            keys = sorted({k for d in done for k in d})
            tbl = pa.table({k: [d.get(k) for d in done] for k in keys})
            pq.write_table(tbl, path + ".tmp")
            os.replace(path + ".tmp", path)
            log(f"phase4a: {i}/{len(pick)} events sampled")
    shutil.rmtree(tmp, ignore_errors=True)
    return summarise_slippage(path)


def summarise_slippage(path):
    t = pq.read_table(path).to_pylist()
    ok = [d for d in t if d.get("status") == "ok"]
    res = {"events": len(t), "usable": len(ok)}
    for l in (1000, 3000):
        v = np.array([d[f"entry_px_{l}"] / d["kline_open"] - 1 for d in ok
                      if d.get(f"entry_px_{l}") and np.isfinite(d[f"entry_px_{l}"])])
        if len(v):
            res[f"entry_{l}ms"] = {q: float(np.percentile(v, q)) for q in (50, 75, 90)}
            res[f"entry_{l}ms_n"] = int(len(v))
    s = np.array([1 - d["stop_px"] / d["stop_level"] for d in ok
                  if d.get("stop_px") and np.isfinite(d["stop_px"])])
    if len(s):
        res["stop"] = {q: float(np.percentile(s, q)) for q in (50, 75, 90)}
        res["stop_n"] = int(len(s))
    with open(os.path.join(os.path.dirname(path), "slippage_summary.json"), "w") as f:
        json.dump(res, f, indent=1)
    return res


def slippage_params(settings, level="p75"):
    """Base case uses the 75th percentile; stress uses the 90th. Fallbacks are
    deliberately pessimistic if 4a has not been run."""
    path = os.path.join(settings.root, "phase4", "slippage_summary.json")
    q = 75 if level == "p75" else 90
    if os.path.exists(path):
        with open(path) as fh:
            s = json.load(fh)
        e = s.get("entry_1000ms", {}).get(str(q)) or s.get("entry_1000ms", {}).get(q)
        st = s.get("stop", {}).get(str(q)) or s.get("stop", {}).get(q)
        if e is not None and st is not None:
            return max(float(e), 0.0), max(float(st), 0.0), "measured"
    return (0.005, 0.015, "fallback") if q == 75 else (0.01, 0.03, "fallback")


# ---------------------------------------------------------------- 4b trades

def funding_cost(funding, t_in, t_out):
    if funding is None:
        return 0.0
    ft, fr = funding
    m = (ft > t_in) & (ft <= t_out)
    return float(fr[m].sum())  # long pays positive rates, receives negative


def simulate_symbol(g, symbol, X, S, T, entry_slip, stop_slip, funding=None, delay=0):
    close, open_, hi, lo, miss = g["close"], g["open"], g["high"], g["low"], g["missing"]
    n = g["n"]
    ret5 = np.full(n, np.nan)
    ret5[5:] = close[5:] / close[:-5] - 1
    gap5 = scan.fwd_count(miss, 6)  # window [t, t+5]
    gap_ok = np.zeros(n, bool)
    gap_ok[5:] = gap5[:-5] == 0
    sig = np.flatnonzero(gap_ok & (ret5 >= X))
    trades, free_at = [], -1
    for t in sig:
        if t < free_at:
            continue
        e = t + 1 + delay
        if e + 2 >= n or miss[t + 1:e + 1].any():
            continue
        entry = open_[e] * (1 + entry_slip)
        stop = entry * (1 - S)
        hh = -np.inf
        exit_px, exit_k, reason = None, None, None
        last = min(n - 1, e + HOLD - 1)
        for k in range(e, last + 1):
            if miss[k]:
                j = k
                while j < n and miss[j]:
                    j += 1
                if j >= n:
                    break
                exit_px, exit_k, reason = open_[j] * (1 - stop_slip), j, "gap"
                break
            if lo[k] <= stop:
                px = min(stop, open_[k]) if k > e else min(stop, entry)
                reason = "trail" if stop > entry * (1 - S) * (1 + 1e-9) else "stop"
                exit_px, exit_k = px * (1 - stop_slip), k
                break
            hh = max(hh, hi[k])
            stop = max(stop, hh * (1 - T))
        if exit_px is None:
            if last <= e or miss[last]:
                continue
            exit_px, exit_k, reason = close[last] * (1 - entry_slip), last, "time"
        t_in, t_out = g["t0"] + e * MIN, g["t0"] + exit_k * MIN + MIN
        gross = exit_px / entry - 1
        fund = funding_cost(funding, t_in, t_out)
        net_ret = gross - 2 * FEE - fund
        trades.append(dict(symbol=symbol, t_in=t_in, t_out=t_out, entry=float(entry),
                           exit=float(exit_px), reason=reason, gross=float(gross),
                           funding=float(fund), net=float(net_ret), R=float(net_ret / S)))
        free_at = exit_k + REENTRY_GAP
    return trades


def variants():
    return [(X, S, T) for X in ENTRY_X for S in STOPS for T in TRAILS]


def vname(X, S, T):
    return f"X{int(X*100)}_S{int(S*100)}_T{int(T*100)}"


def run(manifest, settings, months=scan.DEV_MONTHS, level="p75", delay=0, log=print,
        symbols=None, tag=None):
    for m in months:
        if m in settings.holdout_months:
            raise holdout.HoldoutLocked(f"phase4 refuses holdout month {m}")
    entry_slip, stop_slip, src = slippage_params(settings, level)
    tag = tag or f"{level}_d{delay}"
    out_dir = os.path.join(settings.root, "phase4", f"{months[0]}_{months[-1]}", tag)
    rows = manifest.db.execute(
        "SELECT symbol, first_month, last_month FROM symbols WHERE in_archive=1 ORDER BY symbol").fetchall()
    if symbols:
        rows = [r for r in rows if r[0] in symbols]
    rows = [r for r in rows if r[1] and r[1] <= months[-1] and (r[2] or r[1]) >= months[0]]
    log(f"phase4 {tag}: entry slip {entry_slip:.4f}, stop slip {stop_slip:.4f} ({src}), delay {delay} min")
    allv = {vname(*v): [] for v in variants()}
    for i, (sym, _, _) in enumerate(rows, 1):
        g = scan.load_grid(settings, sym, months, purpose=f"phase4-{tag}")
        if g is None:
            continue
        fp = os.path.join(settings.data_dir, "funding", f"{sym}.parquet")
        funding = None
        if os.path.exists(fp):
            ft = pq.read_table(fp)
            funding = (ft.column("funding_time").to_numpy(), ft.column("funding_rate").to_numpy())
        for X, S, T in variants():
            allv[vname(X, S, T)] += simulate_symbol(g, sym, X, S, T, entry_slip, stop_slip, funding, delay)
        if i % 100 == 0:
            log(f"phase4 {tag}: {i}/{len(rows)} symbols")
    os.makedirs(out_dir, exist_ok=True)
    for v, tr in allv.items():
        scan.write_rows(sorted(tr, key=lambda r: r["t_in"]), os.path.join(out_dir, f"{v}.parquet"))
    with open(os.path.join(out_dir, "params.json"), "w") as f:
        json.dump(dict(entry_slip=entry_slip, stop_slip=stop_slip, source=src, delay=delay,
                       months=list(months), fee=FEE, k_max=K_MAX, risk=RISK), f, indent=1)
    log(f"phase4 {tag} finished -> {out_dir}")
    return out_dir


# ---------------------------------------------------------------- portfolio

def portfolio(trades, k_max=K_MAX, risk=RISK, S=0.05, lev_cap=LEV_CAP):
    """Chronological, at most k_max open, one per symbol, fixed-fractional risk.
    Equity is marked at exits only (drawdown is therefore understated slightly)."""
    eq, peak, mdd = 1.0, 1.0, 0.0
    open_pos, taken, skipped, curve = [], [], 0, []
    events = sorted(trades, key=lambda r: r["t_in"])
    for tr in events:
        still = []
        for p in sorted(open_pos, key=lambda p: p["t_out"]):
            if p["t_out"] <= tr["t_in"]:
                eq += p["pnl"]
                curve.append((p["t_out"], eq))
                peak = max(peak, eq)
                mdd = max(mdd, 1 - eq / peak)
            else:
                still.append(p)
        open_pos = still
        if len(open_pos) >= k_max or any(p["symbol"] == tr["symbol"] for p in open_pos):
            skipped += 1
            continue
        notional = min(risk * eq / S, lev_cap * eq)
        pnl = notional * tr["net"]
        open_pos.append(dict(symbol=tr["symbol"], t_out=tr["t_out"], pnl=pnl))
        taken.append(dict(tr, pnl=pnl, eq_before=eq))
    for p in sorted(open_pos, key=lambda p: p["t_out"]):
        eq += p["pnl"]
        curve.append((p["t_out"], eq))
        peak = max(peak, eq)
        mdd = max(mdd, 1 - eq / peak)
    return dict(taken=taken, skipped=skipped, final=eq, mdd=mdd, curve=curve)


def monthly(curve):
    """Month -> return, from equity at each month's last exit."""
    end = {}
    for t, e in curve:
        end[str(np.datetime64(t, "ms").astype("datetime64[M]"))] = e
    out, prev = {}, 1.0
    for m in sorted(end):
        out[m] = end[m] / prev - 1
        prev = end[m]
    return out


def stats(trades):
    if not trades:
        return None
    R = np.array([t["R"] for t in trades])
    net_ = np.array([t["net"] for t in trades])
    wins, losses = net_[net_ > 0].sum(), -net_[net_ < 0].sum()
    top3 = np.sort(R)[::-1][3:] if len(R) > 3 else R[:0]
    return dict(n=len(R), win=float((net_ > 0).mean()), avgR=float(R.mean()),
                pf=float(wins / losses) if losses else np.inf,
                avgR_ex_top3=float(top3.mean()) if len(top3) else np.nan,
                medR=float(np.median(R)))


# ---------------------------------------------------------------- report

def report(settings, months=scan.DEV_MONTHS):
    base = os.path.join(settings.root, "phase4", f"{months[0]}_{months[-1]}")
    tags = sorted(d for d in os.listdir(base) if os.path.isdir(os.path.join(base, d)))
    L = []
    P = L.append
    P(f"PHASE 4 REPORT  months {months[0]}..{months[-1]}")
    sp = os.path.join(settings.root, "phase4", "slippage_summary.json")
    if os.path.exists(sp):
        with open(sp) as fh:
            P("Measured slippage (Phase 4a): " + fh.read().replace("\n", " "))
    P("Per-trade stats use every signal; portfolio = max 5 open, 0.5% risk per trade.")
    P("Equity is marked at exits only, so drawdown is slightly understated.\n")
    for tag in tags:
        with open(os.path.join(base, tag, "params.json")) as fh:
            prm = json.load(fh)
        P(f"== {tag}: entry slip {prm['entry_slip']*100:.2f}%, stop slip {prm['stop_slip']*100:.2f}% "
          f"({prm['source']}), entry delay {prm['delay']} min, fee {prm['fee']*100:.2f}%/side")
        P(f"{'variant':12} {'n':>6} {'win':>6} {'avgR':>6} {'medR':>6} {'PF':>5} {'avgR-top3':>9} | "
          f"{'taken':>5} {'skip':>6} {'return':>8} {'maxDD':>6} | monthly portfolio returns")
        for X, S, T in variants():
            v = vname(X, S, T)
            fp = os.path.join(base, tag, f"{v}.parquet")
            if not os.path.exists(fp):
                continue
            tr = pq.read_table(fp).to_pylist()
            st = stats(tr)
            if not st:
                P(f"{v:12} no trades")
                continue
            pf = portfolio(tr, S=S)
            mtxt = [f"{m[2:]}:{r*100:+.1f}%" for m, r in monthly(pf["curve"]).items()]
            P(f"{v:12} {st['n']:6d} {st['win']*100:5.1f}% {st['avgR']:6.2f} {st['medR']:6.2f} "
              f"{st['pf']:5.2f} {st['avgR_ex_top3']:9.2f} | {len(pf['taken']):5d} {pf['skipped']:6d} "
              f"{(pf['final']-1)*100:7.1f}% {pf['mdd']*100:5.1f}% | {' '.join(mtxt)}")
        P("")
    text = "\n".join(L)
    with open(os.path.join(base, "REPORT_4.txt"), "w") as f:
        f.write(text + "\n")
    return text
