"""Phase 4 tests: execution rules, no look-ahead in trailing, slippage parser, portfolio."""
import os
import tempfile
import unittest
import zipfile

import numpy as np

from ghr import holdout, klines, phase4
from ghr.config import Settings
from ghr.manifest import Manifest
from test_phase3 import MIN, OCT, grid_from


def bars(o, h, l, c):
    n = len(o)
    return {"t0": OCT, "n": n, "open": np.array(o, float), "high": np.array(h, float),
            "low": np.array(l, float), "close": np.array(c, float),
            "quote_volume": np.ones(n), "missing": np.zeros(n, bool)}


def pump_then(after):
    """10 flat minutes, a 6% jump in 5 minutes (signal at minute 14), then `after` closes."""
    c = [1.0] * 10 + [1.012, 1.024, 1.036, 1.048, 1.06] + list(after)
    o = [c[0]] + c[:-1]
    h = [max(a, b) for a, b in zip(o, c)]
    l = [min(a, b) for a, b in zip(o, c)]
    return bars(o, h, l, c)


class TestExecution(unittest.TestCase):
    def test_trailing_exit_and_costs(self):
        up = list(np.linspace(1.06, 1.5, 60))
        down = list(np.linspace(1.5, 1.0, 60))
        g = pump_then(up + down + [1.0] * 1500)
        tr = phase4.simulate_symbol(g, "X", 0.05, 0.05, 0.15, entry_slip=0.001, stop_slip=0.002)
        self.assertEqual(len(tr), 1)
        t = tr[0]
        self.assertEqual(t["reason"], "trail")
        entry = 1.06 * 1.001
        self.assertAlmostEqual(t["entry"], entry, places=9)
        self.assertLess(t["exit"], 1.5 * 0.85)            # filled at/below the trail, minus slip
        self.assertGreater(t["exit"], 1.5 * 0.85 * 0.98)
        self.assertAlmostEqual(t["net"], t["exit"] / entry - 1 - 2 * phase4.FEE, places=12)
        self.assertAlmostEqual(t["R"], t["net"] / 0.05, places=12)

    def test_initial_stop_and_gap_through(self):
        g = pump_then([1.06, 0.99] + [0.9] * 1500)
        g["open"][16] = 0.95   # opens below the 5% stop (1.007) -> fills at open, not at stop
        g["low"][16] = 0.94
        tr = phase4.simulate_symbol(g, "X", 0.05, 0.05, 0.15, 0.0, 0.0)
        self.assertEqual(tr[0]["reason"], "stop")
        self.assertAlmostEqual(tr[0]["exit"], 0.95)

    def test_trail_uses_only_completed_minutes(self):
        after = [1.06] * 3
        g = pump_then(after + [1.06] * 1500)
        k = 18
        g["high"][k], g["low"][k], g["close"][k] = 2.0, 1.6, 1.9   # same-minute high and low
        tr = phase4.simulate_symbol(g, "X", 0.05, 0.05, 0.15, 0.0, 0.0)
        # trail from 2.0 would be 1.70 > low 1.6; it must NOT trigger in minute k itself
        self.assertNotEqual((tr[0]["t_out"] - OCT) // MIN - 1, k)

    def test_funding_charged_to_long(self):
        g = pump_then([1.06] * 1500)
        ft = np.array([OCT + 100 * MIN, OCT + 600 * MIN])
        fr = np.array([0.001, 0.002])
        tr = phase4.simulate_symbol(g, "X", 0.05, 0.05, 0.15, 0.0, 0.0, funding=(ft, fr))
        self.assertAlmostEqual(tr[0]["funding"], 0.003)
        self.assertAlmostEqual(tr[0]["net"], tr[0]["gross"] - 2 * phase4.FEE - 0.003)

    def test_delay_enters_later(self):
        g = pump_then(list(np.linspace(1.07, 1.2, 30)) + [1.2] * 1500)
        a = phase4.simulate_symbol(g, "X", 0.05, 0.05, 0.15, 0.0, 0.0, delay=0)[0]
        b = phase4.simulate_symbol(g, "X", 0.05, 0.05, 0.15, 0.0, 0.0, delay=1)[0]
        self.assertEqual(b["t_in"] - a["t_in"], MIN)
        self.assertGreater(b["entry"], a["entry"])

    def test_reentry_gap(self):
        g = grid_from(np.ones(4000))
        for start in (100, 200):   # two pumps 100 min apart; first trade stops out quickly
            g["close"][start:start + 5] = np.linspace(1.0, 1.07, 5)
            g["open"][start:start + 5] = g["close"][start:start + 5]
            g["close"][start + 5:start + 7] = 0.9
            g["open"][start + 5:start + 7] = 0.9
            g["low"][start + 5:start + 7] = 0.89
        g["high"] = np.maximum(g["open"], g["close"]) * 1.001
        g["low"] = np.minimum(g["low"], np.minimum(g["open"], g["close"]) * 0.999)
        tr = phase4.simulate_symbol(g, "X", 0.05, 0.05, 0.15, 0.0, 0.0)
        for a, b in zip(tr, tr[1:]):
            self.assertGreaterEqual(b["t_in"] - a["t_out"], phase4.REENTRY_GAP * MIN - MIN)


class TestPortfolio(unittest.TestCase):
    def test_caps_and_one_per_symbol(self):
        trades = [dict(symbol=f"S{i % 7}", t_in=i * MIN, t_out=i * MIN + 1000 * MIN, net=0.01, R=0.2)
                  for i in range(20)]
        pf = phase4.portfolio(trades, k_max=5, S=0.05)
        self.assertEqual(len(pf["taken"]), 5)
        self.assertEqual(pf["skipped"], 15)
        self.assertAlmostEqual(pf["final"], 1 + 5 * (0.005 / 0.05) * 0.01)

    def test_drawdown(self):
        trades = [dict(symbol="A", t_in=0, t_out=10, net=-0.05, R=-1),
                  dict(symbol="A", t_in=20, t_out=30, net=0.10, R=2)]
        pf = phase4.portfolio(trades, S=0.05)
        self.assertAlmostEqual(pf["mdd"], 0.005, places=6)


class TestSlippageParser(unittest.TestCase):
    def test_scan_trades(self):
        t_end = OCT + 61 * MIN
        rows = ["agg_trade_id,price,quantity,first_trade_id,last_trade_id,transact_time,is_buyer_maker"]
        tid = 0
        def add(ts, px, buyer_maker):
            nonlocal tid
            tid += 1
            rows.append(f"{tid},{px},1,{tid},{tid},{ts},{'true' if buyer_maker else 'false'}")
        add(t_end - 5000, 1.00, False)       # before signal close: ignored
        add(t_end + 200, 1.010, False)       # within latency
        add(t_end + 1100, 1.015, True)       # taker sell: not an entry fill
        add(t_end + 1200, 1.020, False)      # first taker buy after 1s
        add(t_end + 3500, 1.030, False)      # first taker buy after 3s
        add(t_end + 60000, 0.960, True)      # crosses 1.02*0.95 = 0.969
        add(t_end + 60500, 0.955, True)      # within stop latency
        add(t_end + 61200, 0.950, True)      # first taker sell after 1s -> stop fill
        with tempfile.TemporaryDirectory() as d:
            zp = os.path.join(d, "a.zip")
            with zipfile.ZipFile(zp, "w") as z:
                z.writestr("X-aggTrades.csv", "\n".join(rows) + "\n")
            r = phase4.scan_trades(zp, t_end)
        self.assertAlmostEqual(r["entry_px_1000"], 1.020)
        self.assertAlmostEqual(r["entry_px_3000"], 1.030)
        self.assertAlmostEqual(r["stop_level"], 1.020 * 0.95)
        self.assertAlmostEqual(r["stop_px"], 0.950)


class TestGuards(unittest.TestCase):
    def test_holdout_refused_and_end_to_end(self):
        with tempfile.TemporaryDirectory() as d:
            st = Settings(root=d)
            os.makedirs(st.data_dir)
            mf = Manifest(st.manifest_path)
            with self.assertRaises(holdout.HoldoutLocked):
                phase4.run(mf, st, months=("2026-07",), log=lambda *_: None)
            g = pump_then(list(np.linspace(1.06, 1.4, 120)) + list(np.linspace(1.4, 1.1, 120)) + [1.1] * 3000)
            n = g["n"]
            cols = {"open_time": [OCT + i * MIN for i in range(n)], "open": list(g["open"]),
                    "high": list(g["high"]), "low": list(g["low"]), "close": list(g["close"]),
                    "volume": [1.0] * n, "close_time": [OCT + i * MIN + 59999 for i in range(n)],
                    "quote_volume": [1.0] * n, "trades": [1] * n, "taker_buy_base": [0.5] * n,
                    "taker_buy_quote": [0.5] * n}
            klines.write_parquet(cols, os.path.join(st.data_dir, "klines", "1m", "XUSDT", "2025-10.parquet"))
            mf.upsert_symbol("XUSDT", in_archive=1, first_month="2025-10", last_month="2025-10")
            phase4.run(mf, st, months=("2025-10",), log=lambda *_: None)
            text = phase4.report(st, months=("2025-10",))
            self.assertIn("X5_S5_T15", text)
            self.assertIn("fallback", text)
            mf.close()


if __name__ == "__main__":
    unittest.main()
